## News
- [POCHE DIGEST](https://poche.app/digest) POCHE DIGEST
- [Dex周刊](https://quaily.com/dingyi) Dex周刊
- [乔木大佬的RSS](https://rss.qiaomu.ai/)
- [papers](https://sophon.at/papers) Trending research and the full catalog - each paper linked to the benchmarks, methods, and models it introduces.
- [repo_posts](https://tom-doerr.github.io/repo_posts/)
- [何夕2077个人站](https://hex2077.dev/)
- [aihot](https://aihot.virxact.com/)
- [bestblogs](https://www.bestblogs.dev/) 付费
- [rss-folo](https://app.folo.is/) 订阅工具

### AIGC
- [image-blaster](https://github.com/neilsonnn/image-blaster) [berryxia x article](https://x.com/berryxia/status/2055086814009180316) 输入图像 → 环境、网格、物理、光照和音频
- [awesome-AI-driven-development](https://github.com/eltociear/awesome-AI-driven-development)
- [awesome-opensource-ai](https://github.com/alvinunreal/awesome-opensource-ai)
- [awesome-3D-generation](https://github.com/justimyhxu/awesome-3D-generation)
- https://github.com/rlczddl/awesome-3d-human-reconstruction
- https://github.com/deepseek-ai/awesome-deepseek-integration
- https://github.com/karminski/one-small-step/
- https://github.com/ikaijua/Awesome-AITools
- [ai-game-development-tools](https://github.com/Yuan-ManX/ai-game-development-tools)
- [StableHoudini](https://github.com/stassius/StableHoudini)
- [chatgpt-guide](https://github.com/Daotin/chatgpt-guide)
- [awesome-ai-painting](https://github.com/hua1995116/awesome-ai-painting)
- [awesome-ai-art](https://github.com/jonathandinu/awesome-ai-art)
- [最大的 AI 工具目录库](https://zhuanlan.zhihu.com/p/593615901)
- [Awesome-Diffusion-Models](https://github.com/heejkoo/Awesome-Diffusion-Models)
- [stablediffusion WebUI](https://docs.google.com/document/d/1hjtuTGaGsi6RNRAhJhceh2qwA7LlH6a44Kma8BIcjX4/edit#heading=h.s72p8wkeghot)
- [元素法典——Novel AI 元素魔法全收录](https://docs.qq.com/doc/DWHl3am5Zb05QbGVs)
- [AI ART](https://www.zhihu.com/column/c_1563238376853258240)
- https://github.com/JPhilipp/AIConnectors
- https://github.com/3DFaceBody/awesome-3dbody-papers
- https://github.com/Yutong-Zhou-cv/Awesome-Text-to-Image
- https://github.com/gongminmin/awesome-aigc
- http://www.aiyjs.com/
- https://github.com/sudoskys/StableDiffusionBook
- [Stable-diffusion-person](https://github.com/KKGo1999/Stable-diffusion-person) 由基于Stable-diffusion的Chilloutmix模型生成高清真实的人像
- [stable-diffusion-webui 的汉化版本](https://github.com/VinsonLaro/stable-diffusion-webui-chinese)
- [喂饭级stable_diffusion_webUI调参权威指南](https://zhuanlan.zhihu.com/p/620578593)
- [StableDiffusion模型资源探索食用指南](https://zhuanlan.zhihu.com/p/597504900)
- [怎样系统的学习 AI 绘画](https://www.zhihu.com/question/585131423/answer/2938150663)
- [AI绘画目前有什么开源模型？](https://www.zhihu.com/question/555400845/answer/2956800568)
- [Midjourney的挑战者 - AI绘图新秀Leonardo.ai](https://zhuanlan.zhihu.com/p/618911569)
- [最大的 AI 工具目录库](https://zhuanlan.zhihu.com/p/593615901)
- [AI收集](https://weknowlib.feishu.cn/wiki/wikcng6M4yAINLrBgMtxrsEAalU)
- [AI绘画收集](https://weknowlib.feishu.cn/wiki/wikcn7hgYG3w4R7JYNJFU2bVjGd)
- https://xa9f20zq7mg.feishu.cn/wiki/JMrEwJEuSiKCQ4kR6xIcQ4BGneg
- https://github.com/karminski/one-small-step




### Audio
- [voicebox](https://github.com/jamiepine/voicebox) Clone any voice. Generate speech. Dictate into any app. Talk to agents in voices you own.
The full voice I/O stack, running locally on your machine.
- [FunASR](https://github.com/modelscope/FunASR) Industrial-grade speech recognition toolkit: 170x realtime, 50+ languages, speaker diarization, emotion detection, streaming, and OpenAI-compatible API.
- [bark](https://github.com/suno-ai/bark)  Text-Prompted Generative Audio Model
- https://github.com/jianchang512/ChatTTS-ui
- https://github.com/panyanyany/Awesome-ChatTTS
- https://github.com/Camb-ai/MARS5-TTS
- https://elevenlabs.io/v3
- https://github.com/DrewThomasson/ebook2audiobook
- https://github.com/fishaudio/fish-speech
- https://huggingface.co/spaces/TTS-AGI/TTS-Arena-V2
- https://github.com/OpenBMB/VoxCPM
- [Hugging Face 刚刚开源了一个完整的实时语音 AI 流程。](https://x.com/RituWithAI/status/2081614165316440193) [github link](https://github.com/huggingface/speech-to-speech)

### Animation
- [EDGE](https://github.com/Stanford-TML/EDGE) Official PyTorch Implementation of EDGE (CVPR 2023)
- [kimodo](https://github.com/nv-tlabs/kimodo) Kimodo is a kinematic motion diffusion model trained on a large-scale (700 hours)
- [Kimodo Unity Bridge ](https://www.bilibili.com/video/BV1HG7361Env/) [KimodoUnityBridge](https://github.com/OneYoungMean/KimodoUnityBridge)
- [kimodo](https://github.com/localai-org/kimodo.cpp)
- [motionbricks](https://nvlabs.github.io/motionbricks/)
- [ImageToMeshAnim](https://github.com/windsmoon/ImageToMeshAnim) Image to mesh anim with AI

## Blender
- [mixar-app](https://github.com/Mixar-AI/mixar-app) Mixar is an AI-powered 3D content creation tool built as a custom fork of Blender 5.0. 

### Video
- [runwayml-gen2](https://research.runwayml.com/gen2)

### Gemini

- https://github.com/PicoTrex/Awesome-Nano-Banana-images
- https://github.com/ZHO-ZHO-ZHO/ZHO-nano-banana-Creation
- https://github.com/gemini-cli-extensions/nanobanana
- https://voyager.nagi.fun/ 

## ComfyUI
- https://www.comfyorg.cn/
- https://github.com/ZHO-ZHO-ZHO/ComfyUI-ArtGallery
- https://github.com/ZHO-ZHO-ZHO/ComfyUI-Workflows-ZHO
- https://github.com/xiwan/comfyUI-workflows
- https://github.com/cubiq/ComfyUI_IPAdapter_plus
- https://github.com/TJ16th/comfyUI_TJ_NormalLighting
- https://github.com/liusida/top-100-comfyui
- https://github.com/kijai/ComfyUI-DynamiCrafterWrapper#
- https://github.com/ZHO-ZHO-ZHO/ComfyUI-ArtGallery
- https://github.com/Comfy-Org/comfy-cli
- https://github.com/aiaiaikkk/ComfyUI-Curve
- https://github.com/ShiroEirin/comfyui-good-anima
- [ComfyUI_VNCCS](https://github.com/AHEKOT/ComfyUI_VNCCS) Visual Novel Character Creation Suite is a comprehensive tool for creating character sprites for visual novels. It allows you to create unique characters with a consistent appearance across all images, which was previously a challenging task when using neural networks.
- [ComfyUI-RMBG](https://github.com/1038lab/ComfyUI-RMBG) 这是一个功能强大的 ComfyUI 自定义节点，专为高级图像背景移除和物体、人脸、服装及时尚元素的精确分割而设计。该工具利用了多种模型，包括 RMBG-2.0、INSPYRENET、BEN、BEN2、BiRefNet、SDMatte 模型、SAM、SAM2 和 GroundingDINO，同时还集成了实时背景替换和增强边缘检测的新功能，从而提高了精度。
- [DVStudio](https://github.com/412845222/DVStudio) DVStudio 是面向 AI 创作者的一站式资产管理与工作流编排工具。从文本描述到图片生成，从视频处理到 3D 场景布局，让创作者专注于创意表达。

## ML

- https://github.com/Balint-H/mj-unity-tutorial?


## Model
- https://github.com/img2threejs/img2threejs
- https://github.com/RareSense/Nova3D
## UI2Code

- https://github.com/leigest519/ScreenCoder
- https://github.com/WebPAI
- https://github.com/xjywhu/Awesome-Multimodal-LLM-for-Code
- https://kombai.com/
- https://github.com/mendableai/open-lovable

#### ChatBot

- https://github.com/tghamm/Anthropic.SDK
- https://github.com/ThinkInAIXYZ/deepchat
- https://github.com/HKUDS/MoChat
- https://github.com/bytebot-ai/bytebot


#### PDF

- https://doc2x.noedgeai.com/
- https://github.com/guaguastandup/zotero-pdf2zh

#### Logo

- https://github.com/Nutlope/logocreator

#### Prompts


## MCP

### MCP-Article
- https://agent-tars.com/2025/03/25/mcp-brings-a-new-paradigm-to-layered-ai-app-development
- https://zhuanlan.zhihu.com/p/1966898272238035080 用过上百款编程MCP，只有这15个真正好用，Claude Code与Codex配置MCP详细教程
- https://www.cnblogs.com/BNTang/p/18815937
- https://www.bilibili.com/video/BV1TEo6YGEnk/
- https://blog.csdn.net/qq_37172634/article/details/123996775
- https://www.cnblogs.com/whuanle/p/18837493
- [AI智能体的技术架构与解决方案](https://www.cnblogs.com/powertoolsteam/p/18921734)




### Collection

- https://smithery.ai/ Smithery.AI - A collection of tools and resources for building AI-powered applications.
- https://mcpstore.co
- https://mcpmarket.com/
- https://mcpmarket.cn/
- https://mcpservers.org/
- https://www.mcp.run/
- https://mcp.so/servers
- https://www.pulsemcp.com/  Browse and discover MCP use cases, servers, clients, and news
- https://glama.ai/mcp/servers
- https://www.aimcp.info/zh
- https://github.com/punkpeye/awesome-mcp-servers
- https://github.com/modelcontextprotocol/servers
- https://cursor.directory/mcp
- https://portkey.ai/mcp-servers
- https://www.blockmcp.ai/

### Framework
- https://github.com/PederHP/mcpdotnet
- https://github.com/modelcontextprotocol/csharp-sdk
- https://github.com/pietrozullo/mcp-use
- https://github.com/nuskey8/McpToolkit
- https://github.com/doggy8088/mcp-cli 輕量的 Rust CLI 與 library，用來和 MCP Model Context Protocol 伺服器互動。

## AI-Game
- https://github.com/YGYOOO/WorldX 一句话生成一个AI自主驱动的世界.
- https://github.com/leigest519/OpenGame OpenGame: Open Agentic Coding for Games
- [GOD](https://github.com/XiaoLuoLYG/GOD) Govern, Observe, Direct - a real-time control room for agent societies
- [FreeUltraCode] https://github.com/wellingfeng/FreeUltraCode FreeUltraCode - AI coding agent for game development: engine workflows, gameplay code, and asset generation.
- [godogen](https://github.com/htdt/godogen) Autonomous game development for Godot, Bevy, and Babylon.js with Claude Code and Codex.
- [GameDesignOS](https://github.com/DY-2026/GameDesignOS) Local-first OS for AI-assisted game design: turn AI-agent sessions into decisions, evidence, experiments, proposals, and durable project memory.

## Game-Design
- https://the-infinite-build.openai.chatgpt.site/ 如何将小说改成游戏
- https://github.com/worldwonderer/novel-to-game 将任何小说蒸馏为可玩的游戏
- [Claude-Code-Game-Studios](https://github.com/Donchitos/Claude-Code-Game-Studios) Turn a single Claude Code session into a full game development studio.
- [ai-game-studio](https://github.com/chaohong-ai/ai-game-studio)
- [ParanoiaSkills](https://github.com/DY-2026/ParanoiaSkills) 把游戏设计工作流做成可安装、可验证、可迁移的 Agent Skill 包
## 2D-Game
- https://github.com/0x0funky/agent-sprite-forge Agent Skill for generating 2D sprite sheets and map, transparent PNG frames, and animated GIFs from prompts
- https://github.com/NO6KIKO/gorest-2d-animation-spritesheet-generator
- https://github.com/Hugo-Dz/spritefusion-pixel-snapper
- [FrameRonin](https://github.com/systemchester/FrameRonin) 视频转序列帧 · 抠图 
- https://github.com/gary149/h3-game-sprites
## Unity
- https://github.com/AlexeyPerov/Unity-Open-MCP
- https://github.com/FunplayAI/funplay-unity-mcp
- https://github.com/Glade-tool/glade-mcp-unity
- [Locus](https://github.com/r1n7aro/Locus) Locus for Unity is an open-source AI Agent for Unity projects.
- [Strada.Brain](https://github.com/okandemirel/Strada.Brain) AI-Powered Development Agent for Unity / Strada.Core Projects
- https://github.com/ninkjin/Claude-Code-Terminal-for-Unity
- https://github.com/Arodoid/UnityMCP
- https://github.com/CoderGamester/mcp-unity
- https://github.com/justinpbarnett/unity-mcp
- https://github.com/youichi-uda/unity-mcp-pro-plugin 147 AI tools for Unity game development via MCP (Model Context Protocol). Connect Claude, Cursor, and AI assistants to your Unity editor
- https://github.com/VR-Jobs/UnityMCPbeta
- https://github.com/IvanMurzak/Unity-MCP
- https://github.com/AnkleBreaker-Studio/unity-mcp-server Unity MCP 服务器——268 种用于 AI 辅助游戏开发的工具。可将 Claude、Cursor 或任何 MCP 客户端连接到 Unity 编辑器和 Unity Hub
- https://github.com/hatayama/uLoopMCP
- https://github.com/Besty0728/Unity-Skills
- https://github.com/akiojin/unity-cli
- https://github.com/yucchiy/UniCli
- https://github.com/youngwoocho02/unity-cli
- https://github.com/stavrosdidakis/Unity-ComfyUI
- https://github.com/dobrado76/Stable-Diffusion-Unity-Integration
- https://github.com/mochi-neko/ChatGPT-API-unity
- https://github.com/cziberpv/unity-bridge
- https://github.com/wang-er-s/AIBridge
- [UnityInvokeAI](https://github.com/unitycoder/UnityInvokeAI)
- https://github.com/KULEEEE/Unity-Agent-For-Claude-Code
- https://github.com/Exano/UnityClaudeCLI
- https://github.com/nowsprinting/gameplay-mcp
- https://github.com/hatayama/unity-cli-loop
- https://github.com/liyingsong99/AIBridge
- https://github.com/TomLeeLive/openclaw-unity-plugin
- [inspector-context-exporter-for-ai](https://assetstore.unity.com/packages/tools/utilities/inspector-context-exporter-for-ai-374162)

## Computer Graphic
- [RenderDocMCP](https://github.com/halby24/RenderDocMCP)
- [renderdoc-for-vscode](https://github.com/Kirkice/renderdoc-for-vscode) Inspect, analyze, and debug GPU captures — without leaving your editor.
## Shader
- https://shaders.com/
- https://github.com/KULEEEE/Claude-Code-For-Unity-Shader
- [Web-Shader-Extractor-Shader-Skill](https://www.notion.so/Web-Shader-Extractor-Shader-Skill-330a885827c3817c8195d5bf558a3e49) 一个 AI Agent Skill，从网页中提取 WebGL / Canvas / Shader 视觉特效代码，反混淆后移植为独立可运行的原生 JS 项目。
## ai spine 动画：
- https://zhuanlan.zhihu.com/p/1986639531613632439
- https://github.com/CognotEngine/amberpipeline
- https://x.com/CognotEngine


### NetWork

- https://github.com/0xKoda/WireMCP An MCP for WireShark (tshark). Empower LLM's with realtime network traffic analysis capability

### Houdini

- https://mcpmarket.com/server/houdini
- https://github.com/capoomgit/houdini-mcp

### Code Analyser

- https://github.com/davidkingzyb/SCAST

### Computer
- https://github.com/ashwwwin/automation-mcp
- https://github.com/Mininglamp-AI/Mano-P
### WebGL

- https://github.com/grokadegames/webgl-mcp

### GameEngineAsset

- https://github.com/berlinbra/binary-reader-mcp

### AIGC
- https://github.com/PsychArch/minimax-mcp-tools

#### DataBase
- https://github.com/orneryd/NornicDB NornicDB is a high-performance graph + vector database built for AI agents and knowledge systems. It speaks Neo4j's (Bolt + Cypher) and qdrant's (gRPC) languages so you can use Nornic with zero code changes, while adding intelligent features including a graphql endpoint, air-gapped embeddings, GPU accelerated search, and other intelligent features
- https://github.com/yichuan-w/LEANN The smallest vector index in the world. RAG Everything with LEANN!
- https://github.com/namidb/namidb NamiDB is a graph database engine built around object storage
- [helix-db](https://github.com/HelixDB/helix-db) HelixDB is a powerful, open-source, graph-vector database built in Rust for intelligent data storage for RAG and AI
- [turbovec](https://github.com/RyanCodrai/turbovec) A vector index built on TurboQuant, written in Rust with Python bindings
- [s4](https://github.com/abyo-software/s4) GPU-accelerated transparent compression S3-compatible storage gateway. Drop-in replacement for AWS S3 endpoints; cuts your S3 bill 50-80% with no app changes (Rust, nvCOMP, zstd).
- [seekdb](https://github.com/oceanbase/seekdb/) The AI-native state store for agents. MySQL-compatible, embedded or server, hybrid vector + full-text search, COW sandboxes
- [zvec](https://github.com/alibaba/zvec)
### Jupyter
- https://github.com/datalayer/jupyter-mcp-server

### Excel
- https://github.com/haris-musa/excel-mcp-server



### interactive

- https://github.com/noopstudios/interactive-feedback-mcp
  
### Chart-MCP
- https://github.com/antvis/mcp-server-chart
### Doc
- https://github.com/docfork/docfork-mcp
 
## vs-code-mcp
- https://github.com/juehang/vscode-mcp-server
- https://github.com/microsoft/semanticworkbench/tree/HEAD/mcp-servers/mcp-server-vscode
- https://github.com/biegehydra/bifrostmcp


## Agent
- https://github.com/steel-dev/awesome-web-agents
- https://github.com/aishwaryanr/awesome-generative-ai-guide
- https://github.com/steven2358/awesome-generative-ai
- https://github.com/armankhondker/awesome-ai-ml-resources
- https://github.com/dair-ai/ML-Papers-of-the-Week
- https://github.com/filipecalegario/awesome-generative-ai
- https://github.com/mahseema/awesome-ai-tools
- https://github.com/kyrolabs/awesome-agents

## Web-Agent
- https://github.com/open-gitagent/clawless

## Agent-Framework
- [openai-cli](https://github.com/openai/openai-cli) Official CLI for the OpenAI API
- [PraisonAI](https://github.com/MervinPraison/PraisonAI) PraisonAI 🦞 - Your 24/7 AI employee team. Automate and solve complex challenges with low-code multi-agent AI that plans, researches, codes, and delivers to Telegram, Discord, and WhatsApp. Handoffs, guardrails, memory, RAG, 100+ LLMs.
- https://github.com/kyegomez/swarms The Enterprise-Grade Production-Ready Multi-Agent Orchestration Framework.
- [SuperAGI](https://github.com/TransformerOptimus/SuperAGI) SuperAGI——一个以开发者为先的开源自主 AI 代理框架。它使开发者能够快速可靠地构建、管理和运行有用的自主代理。
- https://github.com/stepfun-ai/gelab-zero
- https://github.com/TencentCloudADP/youtu-agent
- https://github.com/ashishpatel26/500-AI-Agents-Projects
- https://github.com/evalstate/fast-agent
- https://github.com/The-Pocket/PocketFlow
- https://github.com/humanlayer/12-factor-agents
- https://github.com/emcie-co/parlant
- https://github.com/Xtra-Computing/MegaAgent
- https://github.com/Kong/volcano-sdk The TypeScript SDK for Multi-Provider AI Agents
- https://github.com/lupantech/AgentFlow
- https://github.com/crewAIInc/crewAI
- [pydantic-ai](https://github.com/pydantic/pydantic-ai) Pydantic AI is a Python agent framework designed to help you quickly, confidently, and painlessly build production grade applications and workflows with Generative AI.
- [all-agentic-architectures](https://github.com/FareedKhan-dev/all-agentic-architectures) 35 production-grade agentic AI architectures (Reflexion, LATS, GraphRAG, MemGPT, Voyager, BrowserAgent, ...) — a Python library and runnable textbook with multi-provider LLM support and a 17-task benchmark leaderboard.
- https://github.com/agno-agi/agno
- https://github.com/Tokfinity/InfCode
- https://github.com/Intelligent-Internet/ii-agent
- https://github.com/julep-ai/julep
- https://github.com/sjtu-sai-agents/ML-Master
- https://github.com/MiroMindAI/MiroThinker
- https://github.com/baidu-baige/LoongFlow
- https://github.com/jarrycyx/openlens-ai
- https://github.com/mastra-ai/mastra
- https://github.com/block/goose
- [The Framework for Building Agents](https://github.com/vercel/eve/)
- https://ai-sdk.dev/
- [AnyTool](https://github.com/HKUDS/AnyTool) AnyTool: Universal Tool-Use Layer for AI Agents
- [composio](https://github.com/warpdot-dev/composio) typescript python sdk ai-agents anthropic openapi langchain openai-agents llamaindex mastra vercel-ai mcp oauth saas llm integrations agent-tools automation cloudflare google-gemini tooling rag multi-provider developer-sdk composable-actions webhook-triggers
- https://github.com/langchain-ai/deepagentsjs
- https://github.com/inclusionAI/AEnvironment
- https://github.com/wangziqi06/724-office 7/24 Office — Self-evolving AI Agent system. 26 tools, 3500 lines pure Python, MCP/Skill plugins, three-layer memory, self-repair, 24/7 production


### Common Agent
- https://github.com/kortix-ai/suna
- https://github.com/simular-ai/Agent-S
- https://github.com/hexdocom/lemonai
- https://github.com/china-qijizhifeng/agentic-harness-engineering/
- https://github.com/camel-ai/owl
- https://github.com/Tongyi-MAI/MAI-UI
- https://github.com/jessepwj/CLAWS-UIS CLAWS-UIS 是一个面向真实 Windows 和 macOS 桌面的人类示教计算机操控智能体。
- https://github.com/Fosowl/agenticSeek Fully Local Manus AI.

### Code-Ide
- https://github.com/langchain-ai/mcpdoc
- https://github.com/gersteinlab/LocAgent

### Math

- https://github.com/jihe520/MathModelAgent

### Notebook

- https://github.com/MODSetter/SurfSense
- https://notebooklm.google/

### AI-Meta

- https://github.com/shcherbak-ai/contextgem

### LLM-Interface

- https://github.com/BerriAI/litellm

## Memory
- https://github.com/IAAR-Shanghai/Awesome-AI-Memory 
- https://github.com/TsinghuaC3I/Awesome-Memory-for-Agents
- https://github.com/carsteneu/ai-memory-comparison
- https://github.com/mindscale-noah/MindMemOS/
- https://github.com/akitaonrails/ai-memory Solution for long term memory for agent coding CLIs and to facilitate handoff between different agent vendors
- [TencentDB-Agent-Memory](https://github.com/TencentCloud/TencentDB-Agent-Memory) 让 Agent 沉淀经验，让人专注创造
- [Co-Engram](https://github.com/Co-Engram/Co-Engram) 像大脑一样运作的记忆——随使用增强、出错衰减、自动自我验证
- [Wangdefa.Memory](https://github.com/VinsonWild/Wangdefa.Memory) Wangdefa.Memory 是一个为企业级 Agent 设计的五层记忆体组件，采用「本地优先」的存储策略，达到轻量、可控、可解释。
- [MemHop](https://github.com/qyiun666/MemHop) 你的 Agent 拥有类人记忆 —— 六层认知架构，单文件嵌入式记忆数据库。
- https://github.com/vshulcz/deja-vu
- [nemos](https://github.com/mmlong818/nemos) Multi-persona AI companions that actually remember you — built on a standalone memory engine (layered · MoE routing · contradiction invalidation). Noncommercial.
- [yantrikos](https://github.com/yantrikos/) YantrikDB — The Cognitive Memory Database for AI Agents
- [PaperGuru-Benchmark](https://github.com/PaperGuru-AI/PaperGuru-Benchmark) Lifecycle-Aware Memory for long-horizon LLM agents — 66.05% on PaperBench, 94.66% on SurveyBench, 10 peer-reviewed acceptances at FSE/ICML/TOSEM/AEI/ICoGB
- https://github.com/moorcheh-ai/memanto/
- [memoir](https://github.com/zhangfengcdt/memoir) Hierarchical Memory with Git-Like Version Control
- [hypatia](https://github.com/MarchLiu/hypatia) "We can wander through the stacks of the Library of Alexandria, imagining the scrolls and the knowledge they contain. Its destruction is a warning: all we have is transient.”--Alberto Manguel
- [mcp-memory-service](https://github.com/doobidoo/mcp-memory-service) Open-source memory backend for AI agents — REST API, MCP, OAuth, CLI, dashboard. One self-hosted service, every transport. Agents store decisions, share causal knowledge graphs, and retrieve context in 5ms — without cloud lock-in or API costs.
- [m_flow](https://github.com/FlowElement-ai/m_flow) Retrieval through reasoning and association — M-flow operates like a cognitive memory system.
- [graymatter](https://github.com/angelnicolasc/graymatter) Three lines of code to give your AI agents persistent memory and cut token usage by 90%.
- [sirchmunk](https://github.com/modelscope/sirchmunk)  从原始数据到自我进化的智能，实时进行。
- [agent-memory](https://github.com/neo4j-labs/agent-memory) A graph-native memory system for AI agents and context graphs. Store conversations, build knowledge graphs, and let your agents learn from their own reasoning — all backed by Neo4j. 
- [mempalace](https://github.com/milla-jovovich/mempalace) The highest-scoring AI memory system ever benchmarked. And it's free.
- [Memory-Palace-Openclaw](https://github.com/AGI-is-going-to-arrive/Memory-Palace-Openclaw)
- https://github.com/avasol/galadriel-public
- [mempal](https://github.com/ZhangHanDong/mempal) AI Agent Memory
- [create-context-graph](https://github.com/neo4j-labs/create-context-graph) 创建上下文图将引导您完成交互式向导，并生成完整的项目：
- [muninndb](https://muninndb.com/) Your AI is brilliant. Its memory is broken. MuninnDB gives it total recall — nothing deleted, the right memory always first, associations built automatically from usage patterns alone.
- [supermemory](https://github.com/supermemoryai/supermemory)
- https://github.com/denda188/ClawIntelligentMemory 智能记忆系统 3.3 是一个基于 PARA 架构的三层记忆管理系统,集成了智能检查点,语义搜索,自动分类和两级摘要功能
- https://github.com/aayoawoyemi/Ori-Mnemos Local-first persistent agentic memory powered by Recursive Memory Harness (RMH). Open source must win.
- [gigabrain](https://github.com/legendaryvibecoder/gigabrain) Gigabrain is a local-first memory stack for OpenClaw agents, Codex App, Codex CLI, Claude Code, and Claude Desktop. It converts conversations and native notes into durable, queryable memory, then injects the right context before each prompt so agents stay consistent across sessions.
- [graph-memory](https://github.com/adoresever/graph-memory) Openclaw记忆插件Knowledge Graph + Memory；Knowledge Graph Context Engine for OpenClaw — extracts structured triples from conversations, compresses context 75%, enables cross-session experience reuse
- [agentic-context-engine](https://github.com/kayba-ai/agentic-context-engine) Make your agents learn from experience. Now available as a hosted solution at kayba.ai
- [compound-engineering-plugin](https://github.com/EveryInc/compound-engineering-plugin) Official Compound Engineering plugin for Claude Code, Codex, Cursor, and more
- https://github.com/win4r/memory-lancedb-pro
- https://github.com/sopaco/cortex-mem The production-ready cognitive foundation for autonomous systems such as OpenClaw and Embodied-AI. For memory management, from extraction and search to automated optimization, with SKILL, CLI, API, MCP, and insights dashboard out-of-the-box.
- [hindsight](https://github.com/vectorize-io/hindsight) Hindsight: Agent Memory That Learn
- https://github.com/Yuliu11/DualStack-Agent
- https://github.com/varun29ankuS/shodh-memory Cognitive memory for AI agents — learns from use, forgets what's irrelevant, strengthens what matters. Single binary, fully offline.
- [sage](https://github.com/l33tdawg/sage) Persistent, consensus-validated memory infrastructure for AI agents.
- https://github.com/yoloshii/ClawMem
- https://github.com/mem9-ai/mem9
- https://github.com/khoj-ai/khoj
- https://github.com/Dataojitori/nocturne_memory
- https://github.com/AGI-is-going-to-arrive/Memory-Palace
- https://github.com/28naem-del/mnemosyne
- https://github.com/caviraoss/openmemory
- https://github.com/verygoodplugins/automem
- https://github.com/volcengine/OpenViking OpenViking: The Context Database for AI Agents
- https://github.com/AVIDS2/memorix Cross-Agent Memory Bridge — Your AI never forgets again
- [mem.net](https://github.com/TianqiZhang/mem.net) About
File-first memory infrastructure for AI agents, built with .NET 8 and Azure backends
- https://github.com/jzOcb/ai-agent-memory File-based memory system for AI Agents with automatic TTL, LLM compression, and multi-agent sharing
- https://github.com/memovai/memov
- https://github.com/EverMind-AI/EverMemOS/
- https://github.com/devflowinc/trieve All-in-one platform for search, recommendations, RAG, and analytics offered via API
- https://github.com/bytedance-seed/m3-agent
- https://github.com/topoteretes/cognee
- https://github.com/coleam00/Archon
- https://docs.ragas.io/en/latest/concepts/
- https://www.evidentlyai.com/llm-evaluation-benchmarks-datasets
- https://github.com/BAI-LAB/MemoryOS
- https://github.com/MemTensor/MemOS
- https://rag.deeptoai.com/
- https://github.com/jzOcb/openclaw-memory-management/ AI Agent 记忆管理系统：P0/P1/P2 优先级 + 自动归档，Token 降 78%
- https://github.com/VectifyAI/PageIndex PageIndex: Document Index for Vectorless, Reasoning-based RAG
- https://github.com/toby-bridges/epro-memory LLM-powered agent memory plugin with 6-category classification and L0/L1/L2 tiered structure
- https://github.com/zilliztech/memsearch A Markdown-first memory system, a standalone library for any AI agent. Inspired by OpenClaw.
- https://github.com/0xK3vin/MegaMemory Persistent project knowledge graph for coding agents. MCP server with semantic search, in-process embeddings, and web explorer
- https://github.com/arjunkmrm/recall a skill for claude code and codex to recall past conversations
- https://github.com/gavdalf/total-recall Total Recall — Autonomous Agent Memory. The only memory system that watches on its own. Five-layer observational memory for OpenClaw agents. ~$0.10/month.
- [clawvault](https://github.com/Versatly/clawvault) ClawVault is a structured memory system for AI agents that uses markdown as the storage primitive. It solves the fundamental problem of AI agents losing context between sessions — what we call "context death."
- [AI 的记忆进化史：我们是如何让AI拥有记忆的](https://x.com/nopinduoduo/status/2035018557978030429)
- [写了 1 个月、拆了100+ 篇文档后：我们终于让 4-Agent AI 装上记忆操作系统](https://x.com/servasyy_ai/status/2034078130919665749)

## Rag
- [Token-Saver](https://github.com/Marktechpost/Token-Saver) pdf rag
- [graph-rag-agent](https://github.com/1517005260/graph-rag-agent) 拼好RAG：手搓并融合了GraphRAG、LightRAG、Neo4j-llm-graph-builder进行知识图谱构建以及搜索；整合DeepSearch技术实现私域RAG的推理；自制针对GraphRAG的评估框架|
- https://github.com/mordang7/ContextKeep About Infinite Long-Term Memory for AI Agents (MCP Server)
- https://github.com/OpenBMB/UltraRAG/
- https://github.com/apecloud/ApeRAG
- https://github.com/HKUDS/RAG-Anything
- [arkon](https://github.com/nduckmink/arkon) Arkon 为企业提供集中控制，方便其管理员工如何使用任何 AI 客户端。管理员可以通过单一门户管理资源、访问策略和工作区上下文
- [MimirQ](https://github.com/skygazer42/MimirQ) 全栈开源、中文优先的企业 RAG 知识库
- https://github.com/tobi/qmd mini cli search engine for your docs, knowledge bases, meeting notes, whatever. Tracking current sota approaches while being all local
- [agentic-rag-for-dummies](https://github.com/GiovanniPasq/agentic-rag-for-dummies) Build a modular Agentic RAG system with LangGraph, conversation memory, and human-in-the-loop query clarification

## Vision-Rag
- https://github.com/liangdabiao/deepseek-v4-flash-vision-rag
- https://github.com/liangdabiao/glm-5.3-flash-vision-rag

### Local-LLM
- https://github.com/vllm-project/vllm
- https://github.com/datawhalechina/self-llm/
- https://pinokio.co/
- https://www.canirun.ai/
- https://www.whatcani.run/

## Devops
- https://github.com/derisk-ai/OpenDerisk

## Research
- [CORAL](https://github.com/Human-Agent-Society/CORAL) CORAL 是一个强大而轻量级的基础设施，用于多智能体自主进化，专为自主研究而构建。
- [researchstudio](https://github.com/microsoft/researchstudio) ResearchStudio 是一套涵盖整个研究生命周期的技能集合——从初步的研究方向到最终发表的论文
- [hyperresearch](https://github.com/jordan-gibbs/hyperresearch)  the Most Powerful Deep Research Harness
- [Light-skills](https://github.com/Light0305/Light-skills) 面向科研、竞赛与创新项目的 AI 全流程技能包
- [rw-research-skill](https://github.com/rolandwonglonam/rw-research-skill) Twelve standalone research workflow skills for questions, literature, evidence, design, writing, and submission.
- [AcademicForge](https://github.com/momozi1996/AcademicForge) 面向 Claude Code / OpenCode / Codex 的学术 Skill 选配与安装平台
- [PaperSpine](https://github.com/WUBING2023/PaperSpine) PaperSpine is a motivation-driven skill for learning from strong academic papers, building a paper’s central argument, and rewriting manuscripts through evidence-aware blueprints, revision matrices, and LaTeX-safe audits.
- [OpenAI4S](https://github.com/PKU-YuanGroup/OpenAI4S) 9.9 元豆包API复刻 Claude Science
- https://github.com/ruc-datalab/DeepAnalyze
- https://github.com/yibie/awesome-autoresearch
- https://github.com/burtenshaw/multiautoresearch autonomous open source ai lab
- https://github.com/alchaincyf/darwin-skill 达尔文.skill —— 一个让你的Skill无限进化的系统：评估→改进→测试→保留或回滚
- https://github.com/WecoAI/awesome-autoresearch
- https://github.com/alvinunreal/awesome-autoresearch A curated list of autonomous improvement loops, research agents, and autoresearch-style systems inspired by Karpathy's autoresearch.
- https://github.com/aiming-lab/AutoResearchClaw 聊一个想法。出一篇论文。全自动 & 自演化
- https://github.com/EurekaClaw/EurekaClaw
- https://github.com/SpectrAI-Initiative/InnoClaw A self-hostable AI research workspace for grounded chat, paper study, scientific skills, and research execution.
- https://github.com/uditgoenka/autoresearch Claude Autoresearch Skill — Autonomous goal-directed iteration for Claude Code. Inspired by Karpathy's autoresearch. Modify → Verify → Keep/Discard → Repeat forever.
- https://github.com/sakanaai/ai-scientist-v2 The AI Scientist-v2: Workshop-Level Automated Scientific Discovery via Agentic Tree Search
- https://github.com/evo-hq/evo A plugin for your agentic framework that optimizes code through experiments
- https://github.com/ZJU-REAL/Polaris

### Benchmark
- https://www.tbench.ai/
- https://gaia-benchmark-leaderboard.hf.space/
- https://huggingface.co/spaces/gaia-benchmark/leaderboard
- https://www.swebench.com/
- https://livecodebenchpro.com/
- https://artificialanalysis.ai/
- https://contextarena.ai/
- https://huggingface.co/spaces/lmgame/lmgame_bench
- [AndroidWorld Leaderboard](https://docs.google.com/spreadsheets/d/1cchzP9dlTZ3WXQTfYNhh3avxoLipqHN75v1Tb86uhHo/edit?gid=0#gid=0)
- [ScreenSpot-Pro Leaderboard](https://gui-agent.github.io/grounding-leaderboard/)
- [digbench](https://digbench.ai/#leaderboard)
- https://www.top3d.ai/

## Codex
- [CodexGuide](https://github.com/freestylefly/CodexGuide) CodexGuide：面向全球初学者、创作者、开发者与团队的 Codex 实践指南
- https://github.com/Yeachan-Heo/oh-my-codex Your codex is not alone. Add hooks, agent teams, HUDs, and so much more 
- https://github.com/stellarlinkco/codex The open source coding agent. openai anthropic gemini
- https://linux.do/t/topic/1785189 codex子代理配置
- https://github.com/VoltAgent/awesome-codex-subagents/
- https://github.com/tuannvm/codex-mcp-server MCP server wrapper for OpenAI Codex CLI that enables Claude Code to leverage Codex's AI capabilities directly.
- https://github.com/congwa/codex-autoresearch codex 永动机，避免codex执行一个长任务总是自动停止的问题
- https://github.com/Git-on-my-level/codex-autorunner 只需制定一次计划，然后让您最喜欢的程序员在您睡觉时埋头处理工单——遇到问题时，他们会在 Telegram 或 Discord 上联系您。
- [让Codex回复短一点](https://x.com/hiheimu/status/2077721449226457339)

## claude-code
- [claudish](https://github.com/MadAppGang/claudish) Use your existing AI subscriptions with Claude Code. Works with Anthropic Max, Gemini Advanced, ChatGPT Plus/Codex, Kimi, GLM, OllamaCloud — plus 580+ models via OpenRouter and local models for complete privacy.
- https://github.com/Yeachan-Heo/oh-my-claudecode
- https://github.com/hesreallyhim/awesome-claude-code
- [cc使用技巧](https://www.cnblogs.com/heavenYJJ/p/19071441)
- https://baoyu.io/translations/claude-code-framework-wars
- https://github.com/UfoMiao/zcf
- https://github.com/rz1989s/claude-code-statusline
- https://github.com/Njengah/claude-code-cheat-sheet
- https://github.com/diet103/claude-code-infrastructure-showcase
- https://skillsmp.com/
- https://github.com/claude-did-this/claude-hub
- https://github.com/apstenku123/claude-code-reverse
- https://github.com/AndyMik90/Auto-Claude
- https://github.com/Dev-GOM/claude-code-marketplace
- https://github.com/affaan-m/everything-claude-code
- https://github.com/supermemoryai/claude-supermemory
- https://github.com/thedotmack/claude-mem
- https://github.com/mksglu/claude-context-mode
- https://github.com/louislva/claude-peers-mcp Allow all your Claude Codes to message each other ad-hoc!
- https://github.com/gkaria/vibe-learn A learning companion for the vibe coding era. Watches Claude Code build your software. Helps you understand what was built, why, and how — at your own pace.
- https://github.com/Rangizingo/cc-cache-fix Patch + test toolkit for the known Claude Code cache issues
- https://github.com/hitmux/HitCC Claude Code CLI Node.js版本 v2.1.84 完整逻辑逆向文档
- [clawgod](https://github.com/0Chencc/clawgod) This is NOT a third-party Claude Code client. ClawGod is a runtime patch applied on top of the official Claude Code. It works with any version — as Claude Code updates, the patch continues to take effec
- [hello2cc](https://github.com/hellowind777/hello2cc) Native-first Claude Code plugin for third-party models with silent Agent model injection and output styles.

## Claude-Code-Leak
- [claude-code-from-scratch](https://diwang.info/claude-code-from-scratch/#/) 一步一步，从零造一个 Claude Code
- [claude-code-from-source](https://github.com/alejandrobalderas/claude-code-from-source) best book
- [claw-code-parity](https://github.com/ultraworkers/claw-code-parity) claw-code Rust port parity work - it is temporary work while claw-code repo is doing migration
- [collection-claude-code-source-code](https://github.com/chauncygu/collection-claude-code-source-code)
- [nano-claude-code](https://github.com/SafeRL-Lab/nano-claude-code) Nano Claude Code: A Minimal Python Reimplementation, simple and easy to deploy quickly.
- [nanocode](https://github.com/nanocode-project/nanocode) nanocode: A lightweight AI coding assistant built in Python (~1.9k lines).
- [openclaude](https://github.com/Gitlawb/openclaude) Open Claude Is Open-source coding-agent CLI for OpenAI, Gemini, DeepSeek, Ollama, Codex, GitHub Models, and 200+ models via OpenAI-compatible APIs.
- [openclaude](https://gitlawb.com/node/repos/z6MkqDnb/openclaude) Use Claude Code with any LLM — not just Claude.
- https://github.com/tvytlx/ai-agent-deep-dive claude code 源码分析
- [驾驭工程 — 从 Claude Code 源码到 AI 编码最佳实践](https://zhanghandong.github.io/harness-engineering-from-cc-to-ai-coding/)
- https://github.com/roger2ai/Claude-Code-Compiled Compiled version of Leaked Claude Code
- https://github.com/paoloanzn/free-code The free build of Claude Code. All telemetry removed, security-prompt guardrails stripped, all experimental features enabled. 
- https://github.com/ultraworkers/claw-code Rewriting Project Claw Code
- https://github.com/roger2ai/claude-code-internals 本项目对 Claude Code 的内部架构进行了深度拆解。
- https://ccunpacked.dev/ cc的图形解释
- [claude-code-rust](https://github.com/lorryjovens-hub/claude-code-rust) Rust 全量重构的 Claude Code - 性能提升 2.5x，体积减少 97% | High-performance Rust implementation of Claude Code with 2.5x faster startup and 97% smaller binary
- [claude-code](https://github.com/claude-code-best/claude-code) 原汁原昧 Claude Code 可运行,可构建, 可调试版; Typescript 类型全修复; 企业级可靠性; 安全无毒, lock 文件保真, 可直接 bun i; bun run dev 启动
- [agentic-ai-prompt-research](https://github.com/Leonxlnx/agentic-ai-prompt-research) Research into how agentic AI coding assistants work — reconstructed prompt patterns, agent coordination, and security classification
- [open-agent-sdk-typescript](https://github.com/codeany-ai/open-agent-sdk-typescript) claude code 套壳的agent sdk
- [better-clawd](https://github.com/x1xhlol/better-clawd) Claude Code, but better: better performance, OpenAI/OpenRouter support, no telemetry, no lock-in.
- [Claude-Code-Source-Study](https://github.com/luyao618/Claude-Code-Source-Study) 深入Claude Code源码，学习目前最好的agent实现

## Agent-Inspector
- [monet](https://github.com/zenolab124/monet) Coding Agent 的多引擎指挥台——Claude Code 与 Codex 已同席
- [agentsview](https://github.com/kenn-io/agentsview) Local-first session search, analytics, insights, and token use statistics for coding agents, supporting Claude Code, Codex, and more than 20 other agents.
- [recall](https://github.com/raiyanyahya/recall) Stop wasting tokens and re-explaining your project every session. Recall gives Claude Code durable memory — entirely offline.
- https://github.com/ip2a/memorph 在不同的编程助手之间无损切换会话
- https://github.com/jianshuo/ccglass See exactly what your coding agent sends to the model.
- https://github.com/simple10/agents-observe Real-time observability dashboard for Claude Code agents.
- https://github.com/vicarious11/agenttop htop for AI coding agents. Monitor every token, dollar, and session across Claude Code, Cursor, Kiro, Codex, and Copilot — from a single dashboard.
- https://github.com/kangraemin/claude-inspector See what Claude Code actually sends to the API.
- https://github.com/patoles/agent-flow Real-time visualization of Claude Code agent orchestration — see your agents think, branch, and coordinate as they work.
- https://github.com/f/agentlytics Comprehensive analytics dashboard for AI coding agents — Cursor, Windsurf, Claude Code, VS Code Copilot, Zed, Antigravity, OpenCode, Command Code
- https://github.com/future-agi/traceAI traceAI is an open-source library that gives you full visibility into your AI applications. It captures every LLM call, prompt, token count, retrieval step, and agent decision as structured traces and sends them to whatever observability tool you already use.
- https://github.com/ldegio/agtop top-style TUI for monitoring AI coding agent sessions
- https://github.com/junhoyeo/tokscale top-style TUI for monitoring AI coding agent sessions
- https://github.com/MrQianjinsi/agentic-metric A local-only monitoring tool for AI coding agents.
- https://github.com/graykode/abtop Like htop, but for AI coding agents. Monitor Claude Code & Codex CLI sessions, tokens, context window, rate limits, and ports in real-time.
- https://github.com/Dicklesworthstone/coding_agent_session_search Unified TUI and CLI to index and search your local coding agent session history across 11+ providers (Codex, Claude, Gemini, Cursor, Aider, etc.)
- https://github.com/phuryn/claude-usage
- https://github.com/janekbaraniewski/openusage
- https://github.com/soulduse/ai-token-monitor
- [codeburn](https://github.com/getagentseal/codeburn) See where your AI coding tokens go. Interactive TUI dashboard for Claude Code, Codex, and Cursor cost observability.
- [claude-tap](https://github.com/liaohch3/claude-tap) claude-tap 是给 AI 编程 agent 用的本地代理和 trace 查看器。把 CLI 通过它启动，就能看到真实 API 流量：system prompt、对话历史、工具 schema、工具调用、流式响应、token 用量和请求 diff。
- [Inspector](https://github.com/TokenRollAI/Inspector) Claude API 请求与 SSE 解剖台 —— 一个纯前端、零依赖的离线解析工具。
- [TokenUsageInsights](https://github.com/doggy8088/TokenUsageInsights) Token 戰情室
- [TokenTracker](https://github.com/xiufengsun/TokenTracker) Track every AI token — then bring your usage to life
## Trajectory
- [Trajectory: A Standard Format for Agent Experience Data](https://x.com/Letta_AI/status/2080535211473850822) 
- [gasp](https://github.com/yologdev/gasp) GASP — the Git Agent State Protocol: a standard for portable agent state. The repo is the agent.
- [engram](https://github.com/clickety-clacks/engram)

## Common-Agent
- https://github.com/agentsmd/agents.md
- [agentic-stack](https://github.com/codejunkie99/agentic-stack) A system tray app for macOS and Windows that tracks Claude Code, Codex, and OpenCode token usage, cost, and activity in real time — with a built-in leaderboard, chat, and webhook alerts.

## Skill
- https://github.com/HKUDS/OpenSpace OpenSpace: Make Your Agents: Smarter, Low-Cost, Self-Evolving
- [SkillClaw](https://github.com/AMAP-ML/SkillClaw) Let Skills Evolve Collectively with Agentic Evolver
- [SkillX](https://github.com/zjunlp/SkillX) SkillX: Automatically Constructing Skill Knowledge Bases for Agents
- https://github.com/Teaonly/SKILL.mk SKILL.mk — A Makefile-Format SKILL Document
- https://github.com/ciembor/agent-rules-books AGENTS.md rules / skills for Codex, Cursor, Claude Code, distilled from classic software engineering books about refactoring, architecture, DDD and code quality.
- https://github.com/davidliuk/graph-of-skills Dependency-Aware Structural Retrieval for Massive Agent Skills
- https://github.com/alchaincyf/x-mentor-skill 女娲的第一个「非人类」作品。不是蒸馏一个人，是蒸馏一个领域。
- [总结了最近 X 上爆火的 26 个 SKILL](https://x.com/jinchenma_ai/status/2041422880404328851)
- https://github.com/alchaincyf/nuwa-skill 那何必蒸馏同事？去蒸馏乔布斯、芒格、费曼、马斯克。
只需输入一个名字，女娲自动完成调研、提炼、验证全流程。
- https://github.com/leilei926524-tech/anti-distill 反蒸馏 Skill（anti-distill）
- https://github.com/mgechev/skills-best-practices Write professional-grade skills for agents, validate them using LLMs, and maintain a lean context window.
- https://github.com/ynulihao/AgentSkillOS
- https://github.com/zjunlp/SkillNet 
- https://github.com/shiqichen17/SkillCraft
- https://github.com/Narwhal-Lab/MagicSkills/
- https://github.com/foryourhealth111-pixel/Vibe-Skills An integrated AI capability stack with 340 skills, MCP entry points, agent workflows, and governed execution for planning, coding, research, and automation.
- https://github.com/travisvn/awesome-claude-skills
- https://github.com/ginobefun/deep-reading-analyst-skill/
- https://github.com/anthropics/skills
- https://github.com/numman-ali/openskills
- https://github.com/yusufkaraaslan/Skill_Seekers
- https://github.com/ComposioHQ/awesome-claude-skills
- https://github.com/VoltAgent/awesome-claude-skills
- https://github.com/BehiSecc/awesome-claude-skills
- https://aitmpl.com/skills
- https://claudemarketplaces.com 
- https://github.com/GuDaStudio/skills
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering
- https://github.com/luoling8192/software-design-philosophy-skill 《软件设计的哲学》
- https://github.com/markduan/a-philosophy-of-software-design-skills
- https://github.com/MiniMax-AI/skills
- https://github.com/lijigang/ljg-skills ljg 自定义技能集。

## Skill-Rutor
- [skill-router](https://github.com/Yuzc-001/skill-router) 一层低存在感的 skill 运行时，用来降低 skill-heavy agent 环境里的选择浪费
- [SkillForge](https://github.com/tripleyak/SkillForge) Intelligent skill router and creator for Claude Code and Codex. Analyzes any input to recommend existing skills, improve them, or create new ones from scratch.
- [SkillTree](https://github.com/maipianworni/SkillTree) 为 AI coding agent（Claude Code / Codex CLI 等）打造的 Skill 分层路由树生成器。

## Agent-Config
- https://github.com/mcpware/claude-code-organizer One dashboard to see everything Claude Code loads into context
- https://github.com/doccker/cc-use-exp保留你熟悉的 CLI/IDE，让 Claude Code、Gemini CLI、Codex、Cursor 开箱即用按费力度从低到高，用最少操作获得最大帮助
- [Skills-Manager](https://github.com/xingkongliang/skills-manager)
- https://github.com/Rito-w/skills-manager
- https://github.com/skill-mill/agent-skill-harbor
- https://github.com/skillsgate/skillsgate
- https://github.com/Railly/agentfiles Discover, organize, and edit AI coding agent skills across Claude Code, Cursor, Codex, Windsurf, and more, from inside Obsidian.
- https://github.com/Karanjot786/agent-skills-cli Install skills from the world's largest marketplace and sync them to 45 AI agents including Cursor, Claude Code, GitHub Copilot, Windsurf, Cline, Gemini CLI, Zed, and more — all with a single command.
- https://github.com/miniLV/Plexus About
一键配置各类 AI Agent 工具的 MCP、Skills 和规则；
- https://github.com/Brightwing-Systems-LLC/mcp-manager

## Coding-Agent
- [trueforge](https://github.com/truefoundry/trueforge/) The open-source agent harness - the runtime layer that turns an LLM into a working agent.
- [arc-code](https://github.com/jerber/arc-code)
- [rockycode](https://github.com/cicialgo/rockycode) A coding agent you can talk to — and the harness science to prove it works. amaze amaze!
- [nac](https://github.com/arcee-ai/nac) Give AI agents ambitious work without losing the plot. nac is an open-source harness for long-running tasks, using a central orchestrator, threads, and structured episodes to stay aligned with your intent.
- [grok-build](https://github.com/xai-org/grok-build) SpaceXAI's coding agent harness and TUI. Fullscreen, mouse interactive, extensible.
- [Grok Build 源码拆解](https://xiangyangqiaomu.feishu.cn/docx/OAoYdiZ1eoc2HTxmmZ3clWIPnLf) 
- [AI Coding Agent 架构解剖：从 Grok Build 源码看终端智能体的设计与实现](https://zhanghandong.github.io/grok-build/)
- [ai-agent-book](https://github.com/bojieli/ai-agent-book) 《深入理解 AI Agent：设计原理与工程实践》（李博杰 著）开源主仓库：全书正文、编译版 PDF 与按章配套代码
- [codex-notebook](https://www.luochang.ink/codex-notebook/) 讲解 Codex 工程背后的 15 个核心设计决策
- [dg-ai-notes](https://github.com/buchidonggua/dg-ai-notes) Pi-Agent SDK 深度教程
- [dgzhuya](https://www.dgzhuya.com/) pi
- [pi-book](https://zhanghandong.github.io/pi-book/) pi 的设计艺术：构建生产级 Coding Agent 的架构决策
- [pi-book](https://github.com/antinomie-lab/pi-book) Source-backed architecture notes on building an agent
- [momo-code](https://github.com/momozi1996/momo-code) MOMO CODE — AI coding agent that evolves with you
- [cteno](https://github.com/zalan159/cteno-community) Cteno 是一个跨机器、本地优先的 AI 工作台，面向那些不该因为你合上电脑就停下来的工作。
- [eva](https://github.com/usepr/eva) 单文件智能体
- [CodeAlta](https://github.com/CodeAlta/CodeAlta) Your efficient agentic AI coding CLI assistant
- [metis](https://github.com/Wholiver/metis) Metis 是一个终端优先的 AI 编程智能体。它不只让模型执行命令和修改代码，还围绕编码任务补上搜索、长期经验复用、过程恢复和完成验证，让同一个模型获得更可靠的上下文与执行闭环
- [dao-code](https://github.com/tigicion/dao-code) A terminal coding agent built around cost, experience, and availability — squeezing the most capability and the lowest cost out of the high-value DeepSeek V4.
- https://github.com/agentforce314/clawcodex Token efficient Claude Code full Python rebuild. AI Coding Agent in 230K LoC pure Python. Up to 200X Cost Saving!
- https://github.com/CopilotKit/OpenTag OpenTag: an open-source alternative to Claude in Slack
- [ORG2](https://github.com/yorgai/ORG2) Open-source Cursor-style agent IDE — but built for reviewability and control. Built-in rust harness; supports 10+ CLIs.
- [ouroboros](https://github.com/razzant/ouroboros)  self-creating AI agent. Born Feb 16, 2026.
- [Aura-IDE](https://github.com/CarpseDeam/Aura-IDE) An AI coding harness that shaped itself - Planner/Worker agents, repo awareness, surgical edits, validation, recovery, and safe diff approvals.
- [Maka](https://github.com/Maka-Agent/maka-agent) local-first AI desktop assistant
- https://github.com/lyming99/wenzagent WenzAgent 是一个纯 Dart 实现的 AI Agent 管理框架，提供完整的 Agent 生命周期管理、局域网设备发现与通信、远程过程调用（RPC）以及可扩展的技能系统。无需原生依赖，可跨平台运行。
- [jcode](https://github.com/1jehuang/jcode) Coding Agent Harness 
- https://github.com/konghayao/peri  Rust-built coding agent — fast, lean, Claude Code compatible, any LLM.
- https://www.codebuff.com/
- https://github.com/gi-dellav/zerostack Minimal coding agent written in Rust, inspired by pi and opencode
- https://github.com/vinhnx/vtcode VT Code - semantic AI coding agent
- https://github.com/antinomyhq/forge
- https://github.com/gsd-build/GSD-2
- https://github.com/sst/opencode
- https://github.com/NoeFabris/opencode-antigravity-auth
- https://github.com/letta-ai/letta
- https://github.com/just-every/code
- https://github.com/ConardLi/easy-llm-cli7stt
- https://github.com/tukuaiai/vibe-coding-cn
- [用第一性原理拆解 Agentic Coding：从理论到实操](https://mp.weixin.qq.com/s/Zlwn42KyfjgwfX6lp-JthQ) 
- https://learn.shareai.run/
- [面向 AI Agent 入门者的教学项目](https://github.com/Mr-Q526/Agent-Observability-Demo)
- [hello-agents](https://github.com/datawhalechina/hello-agents) 《从零开始构建智能体》——从零开始的智能体原理与实践教程

## Board-Agent
- https://github.com/chen-985211/cleancode


## PI
- [PiDeck](https://github.com/ayuayue/PiDeck) PiDeck 是一个开源的桌面工作台，用于在本地项目目录中统一管理 pi Agent 会话，并支持导入 Codex、Claude 本地会话以便统一浏览和恢复。支持多项目工作区、会话历史、Git 集成、内置终端、模型配置和插件管理，基于 Electron 构建。
- [对Pi Code Agent生态的整理](https://linux.do/t/topic/2504439)
- https://github.com/badlogic/pi-mono AI agent toolkit: coding agent CLI, unified LLM API, TUI & web UI libraries, Slack bot, vLLM pods
- https://github.com/qualisero/awesome-pi-agent
- [Pi Coding Agent 最全面指南（完美支持/goal）](https://x.com/wquguru/status/2056235143623495975)
- [pi-livecraft](https://github.com/sebastienservouze/pi-livecraft)
- [how-pi-agent-works](https://github.com/cellinlab/how-pi-agent-works) Pi Agent 原理与实现：从零到一实现一个 AI Agent
- https://github.com/nicobailon/pi-subagents
- https://github.com/nicobailon/pi-interactive-shell
- https://github.com/Michaelliv/pi-generative-ui
- https://github.com/nicobailon/pi-messenger
- https://github.com/Michaelliv/pi-dynamic-workflows
- https://github.com/LCorleone/pi-desktop
- https://github.com/shixin-guo/picot
- https://github.com/huiyu9144/Huiyu-Pi
- https://github.com/openchamber/openchamber
- https://github.com/realchendahuang/OMPChamber
- https://github.com/nicobailon/pi-intercom
- https://github.com/am-will/gooey-pi
- https://x.com/xiaomovps/status/2092887927672205740
- https://github.com/kikyous/pi-remote/


## Hermes-Agent
- https://hermesatlas.com/#curated-lists
- https://github.com/fathah/hermes-desktop
- https://github.com/outsourc-e/hermes-workspace Your AI agent's command center — chat, files, memory, skills, and terminal in one place.
- https://github.com/JPeetz/Hermes-Studio
- https://github.com/joeynyc/hermes-hudui Web UI consciousness monitor for Hermes — the AI agent with persistent memory
- https://github.com/xaspx/hermes-control-interface
- https://github.com/NousResearch/hermes-agent
- https://github.com/nesquena/hermes-webui
- https://github.com/OnlyTerp/hermes-optimization-guide
- https://github.com/amanning3390/hermeshub
- [hermes-agent-self-evolution](https://github.com/NousResearch/hermes-agent-self-evolution)  Evolutionary self-improvement for Hermes Agent  optimize skills, prompts, and code using DSPy + GEPA
- [Hermes Agent 从入门到精通](https://github.com/alchaincyf/hermes-agent-orange-book/blob/main/README_zh.md)
- [深入 Hermes Agent 源码](https://github.com/luyao618/Hermes-Source-Code-Study)
- https://github.com/longyunfeigu/learn-hermes-agent Build a production-grade autonomous AI agent from scratch in Python. A 27-chapter, code-first tutorial covering the agent loop, tool system, session persistence, memory, skills, context compression, MCP, multi-platform gateway (Telegram / Discord / Slack / WeChat), and RL-based self-evolution — inspired by Hermes Agent.
- https://github.com/cclank/Hermes-Wiki Hermes agent + LLM Wiki + 源代码 完成 Hermes agent wiki
- https://github.com/GumbyEnder/hermes-kanban
- https://github.com/EKKOLearnAI/hermes-web-ui
- https://github.com/Cranot/super-hermes

## Git-Agent
- https://github.com/open-gitagent/gitagent A universal git-native AI agent framework. Your agent lives inside a git repo — identity, rules, memory, tools, and skills are all version-controlled files.

## Evolving
- [LLM4AD_Next](https://github.com/Optima-CityU/LLM4AD_Next) From problem description to runnable evolutionary algorithm search — in one command.
- [yoyo-evolve](https://github.com/yologdev/yoyo-evolve)
- [GEA](https://github.com/UCSB-AI/GEA) Group Evolving Agents: Open-Ended Self-Improvement via Experience Sharing
- [Raven](https://github.com/EverMind-AI/Raven) Raven is The Self-Improving Agent Harness
- [Skill_MAS](https://github.com/linhh29/Skill_MAS) Evolving Meta-Skill for Automatic Multi-Agent Systems
- [SelfEvolvingAI](https://github.com/primaxlab/SelfEvolvingAI) SelfEvolvingAI - 70模块自我进化AI系统 | Self-evolving AI with 70
- [EvolveR](https://github.com/KnowledgeXLab/EvolveR) Self‑Evolving LLM Agents through an Experience‑Driven Lifecycle
- [sia](https://github.com/hexo-ai/sia) SIA is a Self Improving AI framework to autonomously improve the performance of any AI system (Model / Agent) on a benchmark task.
- [skydiscover](https://github.com/skydiscover-ai/skydiscover) AI-Driven Scientific and Algorithmic Discovery
- [openevolve](https://github.com/algorithmicsuperintelligence/openevolve) Open-source implementation of AlphaEvolve
- [EvoScientist](https://github.com/EvoScientist/EvoScientist) EvoScientist 旨在通过构建自我进化的 AI 科学家来驱动 Vibe Research——让 AI 自主探索、生成洞见并持续迭代优化
- [GenericAgent](https://github.com/lsdefine/GenericAgent) Self-evolving agent: grows skill tree from 3.3K-line seed, achieving full system control with 6x less token consumption
- [autocontext](https://github.com/greyhaven-ai/autocontext) a recursive self-improving harness designed to help your agents (and future iterations of those agents) succeed on any task
- [dspy-agent-skills](https://github.com/intertwine/dspy-agent-skills) Production-grade DSPy 3.2.x agent skills + validated end-to-end examples for Claude Code and Codex CLI — fundamentals, evaluation, GEPA, BetterTogether, and RLM.
- [EvoForge](https://github.com/haizelabs/EvoForge)EvoForge: Evolving Agent Harness Populations
- [future-agi](https://github.com/future-agi/future-agi) Open-source, end-to-end platform for evaluating, observing, and improving LLM and AI agent applications. Tracing · Evals · Simulations · Datasets · Gateway · Guardrails. Self-hostable. Apache 2.0.
- [EvoSkill](https://github.com/sentient-agi/EvoSkill?tab=readme-ov-file) EvoSkill — An open-source framework that automatically discovers and synthesizes reusable agent skills from failed trajectories to improve coding agent performance.
- [autoagent](https://github.com/kevinrgu/autoagent) autonomous harness engineering
- [gepa](https://github.com/gepa-ai/gepa) 利用人工智能驱动的反射式文本演化技术优化提示、代码等。
- [gepa-viz](https://github.com/modaic-ai/gepa-viz) Interactive live visualizer for gepa runs
- [yoyo-evolve](https://github.com/yologdev/yoyo-evolve) A coding agent that evolves itself. One commit per day.
- https://github.com/aiming-lab/MetaClaw Just talk to your agent — it learns and EVOLVES
-[Awesome-Self-Evolving-Agents](https://github.com/EvoAgentX/Awesome-Self-Evolving-Agents)
- https://github.com/EvoAgentX/EvoAgentX 构建自进化的 AI 智能体生态系统
- [OmniAgent](https://github.com/YeQing17-2026/OmniAgent) An agent capable of self-evolving and dynamically hardening security
- https://github.com/Gen-Verse/OpenClaw-RL Empowering OpenClaw with RL — Train a personalized agent simply by talking to it.
- https://x.com/xxx111god/status/2038086450013495554  一个从执行到记忆的完整 Agent Harness: gstack + Compound Engineering：
- [recursive-improve](https://github.com/kayba-ai/recursive-improve) Make your agents recursively self-improve
- [Memento-Skills](https://github.com/Memento-Teams/Memento-Skills) Memento-Skills: Let Agents Design Agents
- [antigravity](https://github.com/study8677/antigravity-workspace-template) The ultimate starter kit for AI IDEs, Claude code，codex, and other agentic coding environments.
- [lat](https://github.com/1st1/lat.md) Agent Lattice: a knowledge graph for your codebase, written in markdown.
- [a-evolve](https://github.com/A-EVO-Lab/a-evolve) The official repository of "Position: Agentic Evolution is the Path to Evolving LLMs".
- [724-office](https://github.com/wangziqi06/724-office) 7/24 Office — Self-evolving AI Agent system. 26 tools, 3500 lines pure Python, MCP/Skill plugins, three-layer memory, self-repair, 24/7 production.

## Harness  
- [HarnessX](https://github.com/Darwin-Agent/HarnessX/) HarnessX 是一个 Harness 铸造厂：从可复用的处理器和 Bundle 中锻造任意数量的 Agent Harness，为每个 Harness 配对任意模型，并通过训练不断进化 —— 全程无需重写 Agent。
- [deepagents-in-action](https://github.com/datawhalechina/deepagents-in-action) 《Deep Agents 实战》—— LangChain 官方大使出品，基于 LangChain / LangGraph 生态，从零构建生产级 AI Agent 的完整指南
- [Natural-Language Agent Harnesses](https://arxiv.org/html/2603.25723v1)
- [learn-harness-engineering](https://walkinglabs.github.io/learn-harness-engineering/zh)
- [OpenHarness](https://github.com/HKUDS/OpenHarness) OpenHarness delivers core lightweight agent infrastructure: tool-use, skills, memory, and multi-agent coordination.
- https://github.com/revfactory/harness A meta-skill that designs domain-specific agent teams, defines specialized agents, and generates the skills they use.
- https://github.com/walkinglabs/awesome-harness-engineering Awesome tools & guides for harness engineering.
- https://github.com/AutoJunjie/awesome-agent-harness A curated list of tools, frameworks, and resources for agent harness engineering 
- https://github.com/wquguru/harness-books Claude Code 设计指南 Claude Code 和 Codex 的 Harness 设计哲学
- [模型不是关键，Harness 才是](https://mp.weixin.qq.com/s/sVGeofV9uTgvhgR44q8pNA)
- [agent-infra-foundation](https://github.com/agent-infra-foundation)
- https://github.com/weijt606/ai-agent-map

## Context
- [magic-context](https://github.com/cortexkit/magic-context) Unbounded context. Memory that manages itself. One session, for life
- [pi-dcp-migrate](https://github.com/Snowy117/pi-dcp-migrate) A port of opencode-dynamic-context-pruning (DCP), adapted to pi's extension model.
- [pi-better-compact](https://pi.dev/packages/pi-better-compact)
- [pi-openai-server-compaction](https://github.com/algal/pi-openai-server-compaction)
- [pi-vcc](https://github.com/monotykamary/pi-vcc)
## Evals
- [awesome-evals](https://github.com/benchflow-ai/awesome-evals) A curated, non-BS library of the best resources for building and evaluating AI agents — papers, blogs, talks, tools, benchmarks. Maintained by BenchFlow.
- https://github.com/lmnr-ai/lmnr
## Prompt
- https://github.com/sanyuan0704/sanyuan-skills
- https://github.com/yaojingang/yao-open-prompts
- https://baoyu.io/blog/google-prompt-engineering-whitepaper
- https://claude.com/blog/best-practices-for-prompt-engineering
- https://github.com/adithya-s-k/AI-Engineering.academy Mastering Applied AI, One Concept at a Time
- https://github.com/1Haschwalth/prompt-engineering/
- https://www.promptingguide.ai/zh
- https://github.com/dair-ai/Prompt-Engineering-Guide
- https://learnprompting.org/zh-Hans
- https://github.com/EmbraceAGI/awesome-chatgpt-zh
- https://github.com/rockbenben/ChatGPT-Shortcut
- [system-prompts-and-models-of-ai-tools](https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools) FULL v0, Cursor, Manus, Same.dev, Lovable, Devin, Replit Agent, Windsurf Agent, VSCode Agent, Dia Browser & Trae AI (And other Open Sourced) System Prompts, Tools & AI Models.
- [chatgpt_system_prompt](https://github.com/LouisShark/chatgpt_system_prompt)
- [leaked-system-prompts](https://github.com/jujumilk3/leaked-system-prompts) Collection of leaked system prompts
- [system_prompts_leaks](https://github.com/asgeirtj/system_prompts_leaks)
- [Prompt工程师指南，源自英文版，但增加了AIGC的prompt部分，为了降低同学们的学习门槛，翻译更新](https://github.com/wangxuqi/Prompt-Engineering-Guide-Chinese)
- [Prompt 如何更好地应用于工业界](https://www.zhihu.com/question/495040812/answer/2924305333)
- https://github.com/microsoft/promptflow
- https://github.com/anthropics/courses
- https://github.com/anthropics/anthropic-cookbook
- https://github.com/NeekChaw/awesome-prompt
- https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools

## Context-Engineering
- https://github.com/Meirtz/Awesome-Context-Engineering
- [从 Prompt 到 Context：基于 1400+ 论文的 Context Engineering 系统综述](https://mp.weixin.qq.com/s/G5BUoM12vu2dWfxzIrAcfg)
- [上下文工程 | Chris Loy](https://baoyu.io/translations/context-engineering-part-of-ml)
- [Context2](https://arxiv.org/abs/2510.26493v1)
- https://github.com/airweave-ai/airweave
- https://www.camel-ai.org/blogs/brainwash-your-agent-how-we-keep-the-memory-clean

## Workflow
- [mattpocock-skill](https://github.com/mattpocock/skills) Skills for Real Engineers. Straight from my .claude directory.
- [prd-manager](https://github.com/wlzh/prd-manager) 一个辅助 Vibe Coding 的 Skill 工具，通过生成结构化的版本需求文档，来指导 AI 进行 Coding ，提升 Coding 的准确性。
- https://github.com/clawplays/ospec Document-driven AI development for AI coding assistants.
- https://github.com/catlog22/Claude-Code-Workflow JSON-driven multi-agent cadence-team development framework with intelligent CLI orchestration (Gemini/Qwen/Codex), context-first architecture, and automated workflow execution
- https://github.com/rohitg00/pro-workflow
- https://github.com/liuzhengdongfortest/CodeStable 厌倦了 OpenSpec 的草台、Oh-My-OpenAgent 的过度设计、Superpowers 的散装——我从 0 写了一套简单轻巧、围绕人在环的 AI Harness。
- https://github.com/Gentleman-Programming/gentle-ai
- https://github.com/tw93/waza Engineering habits you already know, turned into skills Claude can run.
- https://github.com/tobihagemann/turbo A composable dev process for Claude Code, packaged as modular skills. Each skill encodes a dev workflow so you can run it instead of prompting from scratch. Battle-tested with the Opus model.
- https://github.com/fabro-sh/fabro The open source dark software factory for expert engineers.
- https://github.com/GuDaStudio/commands 基于RPI和有效上下文理论，让Claude Code一次只专注于一件事
- https://github.com/henrydiaosi/AI-framework AI 协作开发文档体系 / AI Collaboration Documentation System
- https://zhuanlan.zhihu.com/p/2016213084323217904 Zero-Doc Spec Coding：极简落地指南 
- https://zhuanlan.zhihu.com/p/2018062431721627681 在智能体优先的世界中发挥 Codex 的力量 
- https://github.com/specstoryai/getspecstory Install our local first extensions for your favorite AI IDE or Terminal Agent. Sync your conversations to the cloud. File issues and requests.
- https://github.com/oracle/agent-spec Open Agent Spec (Agent Spec) is a framework-agnostic declarative language for defining agentic systems. It defines building blocks for standalone agents and structured agentic workflows as well as common ways of composing them into multi-agent systems.
- https://github.com/acnlabs/MetaSpec About Meta-specification framework for AI Agents to generate Spec-driven X toolkits automatically.
- https://github.com/gotalab/cc-sdd 
- https://github.com/yibie/SPEC-AGENTS.md This project is inspired by Spec-kit, OpenSpec, and Stack Workflow. It combines the advantages of spec-driven development and phased development. With a small amount of configuration, it helps everyday developers, especially in “vibe coding” sessions, improve the accuracy of AI execution, reduce repeated copy-pasting into the AI, and still enjoy the stability and convenience of mature software engineering workflows.
- https://kiro.dev/docs/specs/concepts/
- https://github.com/amaynez/kiro-style-sdd
- https://github.com/Fission-AI/OpenSpec
- https://github.com/github/spec-kit
- https://github.com/dcramer/dex
- https://github.com/lidangzzz/OnlySpecs
- [flow-kit](https://github.com/rihebty/flow-kit) 一套融合了bmad、spec-kit、OpenSpec、GSD、claude-task-master、superpowers、gstack、skills的 AI 编程规范化流程
- [团队落地 AI 辅助编程和 AI Specs 实战](https://www.cnblogs.com/whuanle/p/19469026)
- [认知重建：Speckit 用了三个月，我放弃了——走出工具很强但用不好的困境](https://www.bestblogs.dev/en/article/0f05763c)
- [planning-with-files](https://github.com/OthmanAdi/planning-with-files)
- [superpowers](https://github.com/obra/superpowers)
- https://github.com/gsd-build/get-shit-done
- https://github.com/mindfold-ai/Trellis AI 编程 Harness，统一 11 个 AI coding 平台
- https://github.com/EveryInc/compound-engineering-plugin/
- [comet](https://github.com/rpamis/comet) Comet: OpenSpec + Superpowers dual-star development workflow
- [workflow-cookbook](https://github.com/AGI-is-going-to-arrive/workflow-cookbook) 《织经》Claude Code Workflows (CLAUDE_CODE_WORKFLOWS) 深度剖析 · 29章+6附录 · 每个配方真跑过
- [claude-code-workflow-research](https://github.com/TokenRollAI/claude-code-workflow-research)
Claude Code Workflow 原理研究(抓包后分析)
- [c-dynamic-workflows](https://cc-dynamic-workflows.pages.dev/) Claude Code 动态工作流(Dynamic Workflows)怎么用
- [claude-dynamic-workflows-codex](https://github.com/scasella/claude-dynamic-workflows-codex)
- [looperators](https://github.com/ObservedObserver/looperators) looperators 把 AI Agent 铺在画布上，连成会自己跑的 loop。
- [loom](https://github.com/valkor-ai/loom/tree/main) Loop engineering for agentic software delivery.
- https://github.com/kaanozhan/Frame Platform for agentic - vibecoders who use claude code and codex cli
- [Aegis](https://github.com/GanyuanRan/Aegis/) Aegis 是一套方法包，让 AI 编程 agent 像有工程纪律的人一样干活——你不需要 全程盯梢。
- [Spexcode](https://github.com/shuxueshuxue/Spexcode/)  SpexCode 在你的 git 仓库里维护一棵带版本的 spec 树,把每个 spec 和它管辖的代码链接起来,并运行一个会话管理器
 
## Agent-Loop
- https://github.com/alchaincyf/loop-engineering-orange-book
- https://github.com/cobusgreyling/loop-engineering
- https://github.com/fainir/most-capable-agent-system-prompt Most Capable Agent System Prompt
- https://github.com/subsy/ralph-tui
- https://github.com/snwfdhmp/awesome-ralph
- https://github.com/mikeyobrien/ralph-orchestrator
- https://github.com/strands-agents/agent-sop
- https://github.com/ClaytonFarr/ralph-playbook
- https://github.com/kunchenguid/gnhf Before I go to bed, I tell my agents: good night, have fun
- [ralphex](https://github.com/umputun/ralphex) Autonomous plan execution with Claude Code and codex

## Parallel Agent Runners
- [rmux](https://github.com/Helvesec/rmux/) Universal Rust multiplexer with a typed SDK — drive any CLI or TUI app from code. Native on Linux, macOS, and Windows.
- [CLI-Manager](https://github.com/dark-hxx/CLI-Manager) A multi-project AI CLI workspace for local terminals, SSH hosts, and mobile-assisted workflows
- [terax-ai](https://github.com/crynta/terax-ai) Lightweight (7MB) AI terminal emulator (ADE) built in Rust & Tauri & React
- [nezha](https://github.com/hanshuaikang/nezha) Run multiple AI coding agents across projects (Claude Code and Codex)
- [AITerm](https://github.com/zzyong24/AITerm) AITerm 是一款基于 Electron + Vue 3 构建的多终端管理器，将终端、代码编辑器、Git 操作和文件浏览整合进一个工作区。支持跨端状态同步，重启后自动还原终端会话和编辑器状态。
- [TermHive](https://github.com/0x0funky/TermHive) The human-driven multi-agent dashboard.
- [Vibe99](https://github.com/NekoApocalypse/Vibe99) Multi-agent terminal app
- [paseo](https://github.com/getpaseo/paseo) One interface for all your Claude Code, Codex and OpenCode agents.
- [paseo-notifier](https://github.com/winezer0/paseo-notifier) Fix the bug where Paseo fails to provide audible notifications
- [onorca](https://www.onorca.dev/) Run Claude Code, Codex, OpenCode, and more side by side in isolated worktrees.
Ghostty-inspired terminals, a built-in file editor, and git tracking keep every branch moving.
- https://github.com/jingyi0605/CodingNS CodingNS 致力于提供一整套闭环的 AI 编程工作流程，让你能够随时随地通过任何客户端进行 AI 编程。无论你使用桌面电脑、移动设备还是 Web 浏览器，都能无缝续接你的 AI 编程会话。
- https://github.com/AnganSamadder/opentmux An OpenCode plugin that provides smart tmux integration for viewing agent execution in real-time. Automatically spawns panes, streams output, and manages your terminal workspace.
- https://github.com/peters/horizon
- https://conductor.build/
- https://github.com/penso/arbor 
- https://jean.build/
- https://superset.sh
- https://air.dev/
- https://psmux.pages.dev/
- https://github.com/mkurman/cmux-windows

- https://github.com/jazzyalex/agent-sessions Session browser + Agent Cockpit + Analytics + Limits tracker for Codex CLI, Claude Code, OpenCode, Gemini CLI, Factory Droid , GitHub Copilot CLI & OpenClaw. Search/filter ALL past sessions, archive sessions, resume instantly, see rate limits in real-time. Native macOS app.
- https://github.com/jakemor/kanna A beautiful web UI for the Claude Code & Codex CLIs
- https://github.com/DeadWaveWave/opencove

- [1code](https://github.com/21st-dev/1code) - UI for Claude Code with local and remote agent execution.
- [agent-deck](https://github.com/asheshgoplani/agent-deck) - Terminal session manager for AI coding agents.
- [agent-of-empires](https://github.com/njbrake/agent-of-empires) - A terminal session manager for AI coding agents on Linux and macOS.
- [agent-orchestrator](https://github.com/ComposioHQ/agent-orchestrator) - Agentic orchestrator for parallel coding agents.
- [ai-maestro](https://github.com/23blocks-OS/ai-maestro) - Dashboard for orchestrating Claude, Aider, and Cursor agents across machines.
- [aizen](https://github.com/vivy-company/aizen) - macOS workspace for managing git worktrees with integrated agent sessions.
- [amux](https://github.com/andyrewlee/amux) - TUI for easily running parallel coding agents.
- [Aperant](https://github.com/AndyMik90/Aperant) - Autonomous multi-session AI coding.
- [ariana](https://github.com/ariana-dot-dev/ariana) - The IDE of the future.
- [automaker](https://github.com/AutoMaker-Org/automaker) - Autonomous AI development studio.
- [bernstein](https://github.com/chernistry/bernstein) - Deterministic orchestrator — spawns parallel AI coding agents (Claude Code, Codex CLI, Gemini CLI), verifies with tests, auto-commits. Zero LLM tokens on coordination.
- [claude-squad](https://github.com/smtg-ai/claude-squad) - Manage multiple AI terminal agents in background.
- [clideck](https://github.com/rustykuntz/clideck) - WhatsApp-like dashboard for managing multiple AI coding agents (Claude Code, Codex, Gemini CLI, OpenCode) in one browser window. Live status, session resume, autopilot routing between agents, and full control from a phone while away.
- [cmux](https://github.com/manaflow-ai/cmux) - Open-source platform for running multiple coding agents in parallel.
- [CodexMonitor](https://github.com/Dimillian/CodexMonitor) - Orchestrate multiple Codex agents across local workspaces.
- [collaborator](https://github.com/collaborator-ai/collab-public) - A place to create with agents.
- [constellagent](https://github.com/owengretzinger/constellagent) - macOS app for running multiple AI agents with their own terminal, editor, and git worktree.
- [crystal](https://github.com/stravu/crystal) - Run multiple Codex and Claude Code sessions in parallel git worktrees.
- [dmux](https://github.com/standardagents/dmux) - Parallel agents with tmux and worktrees.
- [emdash](https://github.com/generalaction/emdash) - Run multiple coding agents in parallel.
- [ghast](https://github.com/aidenybai/ghast) - Multitask with multiple terminals.
- [humanlayer](https://github.com/humanlayer/humanlayer) - Get AI coding agents to solve hard problems in complex codebases.
- [jat](https://github.com/joewinke/jat) - The World's First Agentic IDE.
- [jean](https://github.com/coollabsio/jean) - Desktop & web app for orchestrating coding agents (Claude, Codex, OpenCode) across projects and git worktrees.
- [lalph](https://github.com/tim-smart/lalph) - LLM agent orchestrator driven by your chosen source of issues.
- [mux](https://github.com/coder/mux) - A desktop app for isolated, parallel agentic development.
- [parallel-code](https://github.com/johannesjo/parallel-code) - Desktop app for orchestrating multiple AI coding agents (Claude Code, Codex CLI, Gemini CLI) simultaneously in isolated git worktrees with built-in diff viewer and one-click merge.
- [sortie](https://github.com/sortie-ai/sortie) - Turns issue tracker tickets into autonomous coding agent sessions. Agent-agnostic, tracker-agnostic, single Go binary with SQLite persistence.
- [subtask](https://github.com/zippoxer/subtask) - Claude Skill to do tasks with subagents in Git worktrees.
- [supacode](https://github.com/supabitapp/supacode) - Native macOS coding agent orchestrator.
- [superset](https://github.com/superset-sh/superset) - A terminal built for coding agents.
- [symphony](https://github.com/openai/symphony) - Turns project work into isolated, autonomous implementation runs.
- [t3code](https://github.com/pingdotgg/t3code) - Minimal web GUI for coding agents.
- [tutti](https://github.com/nutthouse/tutti) - Multi-agent orchestration CLI with config-driven workflows, git worktree isolation, and typed artifact flow between agents.
- [vibe-tree](https://github.com/sahithvibudhi/vibe-tree) - Vibe code with Claude in parallel git worktrees.
- [vibecraft](https://github.com/rayzhudev/vibecraft) - An RTS-style workspace for managing AI coding agents.
- [EnsoAI](https://github.com/j3n5en/EnsoAI) Unleash parallel intelligence within a single project.

## Agent2Agent
- [acpx](https://github.com/openclaw/acpx) Headless CLI client for stateful Agent Client Protocol (ACP) sessions
- [imclaw](https://github.com/smallnest/imclaw) acp skill for openclaw, claude cc, codex, gemini cli, pi and others
- [agent-mailer](https://github.com/stelee410/agent-mailer) AMP (Agent Mailer Protocol) is an async mailbox system for AI agents. Instead of chaining tools, writing DAGs, or building RPC glue — agents just send messages to each other. Works with Claude Code, Codex, Cursor, OpenClaw and any custom agents. Designed for real-world, long-running, iterative coding workflows
- [shire](https://github.com/victor36max/shire) - Persistent workspaces for AI agent teams with inter-agent mailboxes, shared drive, and full context preservation. Supports Claude Code, OpenCode, Pi Agent and more.
- [agentic-inbox](https://github.com/cloudflare/agentic-inbox) A self-hosted email client with an AI agent, running entirely on Cloudflare Workers
- [mails](https://github.com/chekusu/mails) email for agents. Built for AI agents that need to send, receive, and understand emails programmatically
- [xurl](https://github.com/Xuanwo/xurl) xURL: Client for AI Agents URLs
- [Avernet](https://github.com/inclusionAI/Avernet) Distributed agent coordination platform where agents live, connect, coordinate, execute, and evolve together.
- [Cotal](https://github.com/Cotal-AI/Cotal) The open standard for agent coordination
- [Confer](https://github.com/hyhmrright/Confer) A protocol and platform for AI Agents to talk with each other on behalf of their owners
- [hcom](https://github.com/aannoo/hcom) - Hook your AI coding agents together so they can message, watch, and spawn each other across terminals.
  
## Agent-Canvas
- [termcanvas](https://github.com/blueberrycongee/termcanvas) An infinite canvas desktop app for visually managing terminals 
- [cate](https://github.com/0-AI-UG/cate) An infinite zoomable canvas for coding — editor, terminal, and browser panels in a spatial workspace.
- [lemma-platform](https://github.com/lemma-work/lemma-platform) The open-source workspace where humans and AI agents work as one team.

## Orchestration 
- [munder-difflin](https://github.com/chaitanyagiri/munder-difflin) local multi-agent harness
- [open-multi-agent](https://github.com/open-multi-agent/open-multi-agent) 这是一个基于 TypeScript 的 AI 代理编排框架，支持动态工作流。请描述目标，而非图：协调器在运行时规划任务 DAG，并将其运行在任何 LLM（Claude、ChatGPT、Gemini、DeepSeek 或本地模型）上。
- [bernstein](https://github.com/sipyourdrink-ltd/bernstein) Bernstein 是一个面向 CLI 编码智能体（Claude Code、Codex、Gemini CLI 以及 40 多个其他智能体）的确定性编排器
- [loopx](https://github.com/huangruiteng/loopx) The local control plane for long-running AI agent work.
- [aiwg](https://github.com/jmagly/aiwg) Cognitive architecture for AI-augmented software development. Specialized agents, structured workflows, and multi-platform deployment. Claude Code · Codex · Copilot · Cursor · Factory · Warp · Windsurf.
- [harnessrouter](https://github.com/HarnessRouter/harnessrouter) HarnessRouter Community Edition: the self-hosted, Apache-2.0 edition of the unified interface for agent harnesses. Run Codex, Claude Code, Hermes, and more through one API, with sessions, streaming, files, cancellation, and failure handling. Implements the Unified Harness Protocol (UHP), an open standard. Your keys, your infrastructure
- [agent-orchestrator](https://github.com/Untrivial-ai/agent-orchestrator)
- [openteams](https://github.com/openteams-lab/openteams) openteams 是一款开源、本地优先的 AI 桌面应用，帮助独立开发者通过一支可控的 AI 团队，更快地规划、构建和交付软件。
- https://www.cnblogs.com/Qiniu-developer/p/22543566


## IM-Agent-Swarm&&Control-Plane
- [buzz](https://github.com/block/buzz) Buzz is a self-hostable workspace where humans and AI agents share the same rooms.
- [qm](https://github.com/yc-software/qm) Multiplayer agent harness for work
- [commonly](https://github.com/Team-Commonly/commonly) Open-source room for humans + cross-vendor AI agents. Every agent gets its own name, memory, skills, and workstation. Any runtime, your infra — no per-agent fees.
- [polynoia](https://github.com/JuneQQQ/polynoia/blob/main/README.zh-CN.md) Polynoia 是一个面向 Agentic Software Development 的 IM 形态多 Agent 协作平台。 它不把每个编码 Agent 隔离成一个终端会话,而是给它们一个共享工作区、聊天式协调层, 以及从想法 → 文件 → 预览 → 提交的可审查路径。
- [Codeg](https://github.com/xintaofei/codeg) Codeg (Code Generation) is an enterprise-grade multi-agent coding workspace. It unifies local AI coding agents (Claude Code, Codex CLI, OpenCode, Gemini CLI, OpenClaw, etc.) in one desktop app with session aggregation, parallel git worktree development, MCP/Skills management, and integrated Git/file/terminal workflows.
- [wayland](https://github.com/FerroxLabs/wayland) Wayland - The AI Agent That Perceives. Reasons. Acts. Evolves.
- [StaffDeck](https://github.com/OpenBMB/StaffDeck) StaffDeck是一套面向企业的数字员工构建与管理平台，帮助专业员工将工作经验、业务流程和判断标准固化为可以持续工作的数字员工，接手重复性任务，并将个人能力沉淀为可复用、可迭代、可追溯的组织资产
- [mobius](https://github.com/nutshellai-tech/mobius) The first self-evolving open-source Agent OS
One system to connect your team, AI agents, devices, and compute
- [desktop-cc-gui](https://github.com/zhukunpenglinyutong/desktop-cc-gui/) CC GUI 客户端（专为开发者打造的VibeCoding平台）
- [zano](https://github.com/EryouHao/zano) Zano lets you spin up persistent AI agents that live in chat channels alongside your team. Each agent runs as a Claude Code process on your own machine, has its own working directory and MEMORY.md, and communicates over chat, DMs, threads, and a built-in task board 
- [openagents](https://github.com/openagents-org/openagents) One workspace where all your AI agents collaborate. Open source. No account required.
- [agent-teams-ai](https://github.com/777genius/agent-teams-ai) You're the CTO, agents are your team. They handle tasks themselves, message each other, review each other's code. You just look at the kanban board and drink coffee.
- [Maestro](https://github.com/RunMaestro/Maestro) Agent Orchestration Command Center
- [cccc](https://github.com/ChesterRa/cccc)  Coordinate your coding agents like a group chat — read receipts, delivery tracking, and remote ops from your phone. One pip install, zero infrastructure. A production‑minded orchestrator for 24/7 workflow
- [bitdance-agenthub](https://github.com/lizyoko9/bitdance-agenthub/) AgentHub 是一个 local-first 的多 Agent 协作工作空间，把 AI 协作做成 IM 群聊式的体验。
- [freebuddy](https://github.com/maojindao55/freebuddy) A desktop workbench for local coding agents. 
- [AstrBot](https://github.com/AstrBotDevs/AstrBot) AI Agent Assistant & development framework that integrates lots of IM platforms, LLMs, plugins and AI feature, and can be your openclaw alternative
- [Orkas](https://github.com/Orkas-AI/Orkas)  Orkas 是一个开源、本地优先的 AI 工作团队。一个超强指挥官会协调多个专业智能体，共同完成复杂工作
- [codexloom](https://github.com/yan5xu/codexloom) A working environment for long-running Codex Agents.
- [OpenMausBot](https://github.com/milind-soni/OpenMausBot) Your own team of AI bots, in a chat app.
- [rakazo](https://github.com/elie222/rakazo) rakazo
- [opc-nexus](https://github.com/h4dex/opc-nexus)  开源的企业版的数字员工工作台
- [ordinus](https://github.com/muratgur/ordinus) Your local-first command center for working with AI agents like a real team.
- [macro](https://github.com/macro-inc/macro) Macro is a unified workspace for teams: email, chat, docs, tasks, agents, calls, and CRM — @-linked together with shared AI memory
- [cumora](https://github.com/yetone/cumora) Cumora is a chat app for humans and AI agents. Each agent has a persona, memory, their own status, and the freedom to start their own conversations
- [agentchat-hermes](https://github.com/agentchatme/agentchat-hermes) AgentChat platform plugin for Nous Research's Hermes Agent runtime — peer-to-peer messaging for autonomous agents over WebSocket. Bundles the agent etiquette skill.
- [openbot](https://github.com/CopilotKit/openbot) Open-source AI coworkers that each get a computer of their own: a browser, files and tools, with every action decided before it happens and recorded after. Bring any AG-UI agent.
- [Gold-Band](https://github.com/diodeme/Gold-Band/) 本地优先的 AI Agent 桌面客户端直接对话、固定工作流与 AI 动态编排，统一管理本地 Coding Agent
- [Lody](https://github.com/LodyAI/Lody) 为团队正在使用的 Coding Agents 提供一个共享工作空间。

## Multi-Agent Swarms
- [homerail](https://github.com/xiaotianfotos/homerail) Voice-first local agent orchestration runtime for auditable DAG workflows.
- [Reina-Agent](https://github.com/Reina-Agent) 桌面 AI 智能体 —— 多智能体协作、MCP 与 Skills、自带模型
- [claude_codex_bridge](https://github.com/SeemSeam/claude_codex_bridge) Agent CLI 聚合和团队
- [claude_code_bridge](https://github.com/bfly123/claude_code_bridge) - Real-time multi-AI collaboration.
- [crew44](https://github.com/getcrew44/crew44) Crew44 turns the AI agents you already run into coordinated teams. Specialists sit in one workspace, hand off the baton, and accumulate skills with every run. Everything stays on your machine.
- [hive](https://github.com/tt-a1i/hive) Browser-native hive-mind for CLI coding agents — Claude Code, Codex, Gemini, and OpenCode collaborate as real PTY processes via a team protocol.
- [MagesticAI](https://github.com/dataseeek/MagesticAI) SDD (Spec-Driven Development) — a cloud and web-based AI task management and agent orchestration platform powered by LLMs
- [claw-empire](https://github.com/GreenSheep01201/claw-empire) Command Your AI Agent Empire from the CEO Desk — A local-first AI agent office simulator that orchestrates CLI, OAuth, and API-connected agents
- [antfarm](https://github.com/snarktank/antfarm) - Build your agent team in OpenClaw with one command.
- [jiuwenswarm](https://github.com/openJiuwen-ai/jiuwenswarm) 您的随叫随到人工智能管家——让智能触手可及
- [automata](https://github.com/sentientwave/automata) - Agent swarming organization system.
- [claude-flow](https://github.com/ruvnet/claude-flow) - Deploy multi-agent swarms with coordinated workflows.
- [clawe](https://github.com/getclawe/clawe) - Multi-agent coordination system: think Trello for OpenClaw agents.
- [ClawTeam](https://github.com/HKUDS/ClawTeam) - Agent Swarm Intelligence (One Command → Full Automation).
- [CompanyHelm](https://github.com/CompanyHelm/companyhelm) - Distributed multi-agent orchestrator with task management and agent-to-agent conversations
- [gastown](https://github.com/steveyegge/gastown) - Multi-agent orchestration system with persistent work tracking.
- [gnap](https://github.com/farol-team/gnap) - Git-Native Agent Protocol: coordinate multiple agents via a shared git repo acting as a persistent task board (todo/doing/done), no orchestrator process required.

- [kodo](https://github.com/ikamensh/kodo) - Autonomous multi-agent coding orchestrator that directs Claude Code, Codex, and Gemini CLI agents through work cycles with independent verification.
- [loom](https://github.com/ghuntley/loom) - Infrastructure for evolutionary software where autonomous loops evolve products.
- [multi-agent-shogun](https://github.com/yohey-w/multi-agent-shogun) - Samurai-inspired tmux orchestrator with a shogun → karo → ashigaru hierarchy for running up to 10 parallel AI coding agents (Claude Code, Codex, Copilot, Kimi) with zero coordination API cost.
- [openfang](https://github.com/RightNow-AI/openfang) - Open-source Agent Operating System.
- [opengoat](https://github.com/marian2js/opengoat) - Build AI autonomous organizations of OpenClaw agents.
- [orc](https://github.com/spencermarx/orc) - Hierarchical multi-agent orchestrator that coordinates AI coding agents through planning, task decomposition, isolated worktrees, and review pipelines.
- [ORCH](https://github.com/oxgeneral/ORCH) - CLI runtime for managing Claude Code, Codex, and Cursor as typed agent teams with state machine, goals, and TUI.

- [skillfold](https://github.com/byronxlg/skillfold) - Configuration language and compiler for multi-agent AI pipelines. Compiles YAML config into agent skills for Claude Code, Cursor, Codex, Copilot, Gemini CLI, and Windsurf.
- [swarm-protocol](https://github.com/phuryn/swarm-protocol) - Headless coordination layer exposed as MCP server: claim work, detect file conflicts, heartbeat, and hand off tasks across agent sessions.
- [wit](https://github.com/amaar-mc/wit) - Coordination protocol that locks specific functions (not files) via Tree-sitter AST parsing. Agents declare intents, acquire symbol level locks, and get conflict warnings before writing code.
- [awesome-agent-orchestrators](https://github.com/andyrewlee/awesome-agent-orchestrators)
- [rowboat](https://github.com/rowboatlabs/rowboat) Open-source AI coworker, with memory
- [open-multi-agent](https://github.com/JackChen-me/open-multi-agent) typeScript framework for multi-agent orchestration. One runTeam() call from goal to result — the framework decomposes it into tasks, resolves dependencies, and runs agents in parallel.
- [ao-cli](https://github.com/launchapp-dev/ao-cli) Animus turns a single YAML file into an autonomous software delivery pipeline.
- [HolyClaude](https://github.com/CoderLuii/HolyClaude) AI coding workstation: Claude Code + web UI + 5 AI CLIs + headless browser + 50+ tools
- [OpenSwarm](https://github.com/unohee/OpenSwarm) OpenSwarm — Autonomous AI dev team orchestrator powered by Claude Code CLI. Discord control, Linear integration, cognitive memory.
- [swarmclaw](https://github.com/swarmclawai/swarmclaw) SwarmClaw is a self-hosted AI runtime for OpenClaw and multi-agent work. It helps you run autonomous agents and orchestrators with heartbeats, schedules, delegation, memory, runtime skills, and reviewed conversation-to-skill learning across OpenClaw gateways and other providers.

- [nexus](https://github.com/PermaShipAI/nexus) An open-source multi-agent AI system that adds judgement, verification, and initiative to AI-assisted software development.
- [oh-my-claudecode](https://github.com/Yeachan-Heo/oh-my-claudecode) Claude Code 的多智能体编排系统。零学习曲线。 无需学习 Claude Code，直接使用 OMC。
- [hive](https://github.com/aden-hive/hive) 构建可靠的、自主的、自我改进的 AI 智能体，无需硬编码工作流
- [AllBeingsFuture](https://github.com/AllBeingsFuture/AllBeingsFuture) AllBeingsFuture 是一个面向多 Agent 协作场景的桌面 AI 工作台，基于 Electron + React 构建，聚焦于把不同 AI Provider、会话、子 Agent、MCP、Skill、Git Worktree 和本地开发环境整合到同一个应用里。
- https://github.com/GoogleCloudPlatform/scion Run multiple agents in parallel — each in its own container, with its own workspace, collaborating on your code or project files simultaneously.
- https://github.com/SethGammon/Citadel Agent orchestration harness for Claude Code. Four-tier routing (/do), campaign persistence across sessions, parallel agents in isolated worktrees, discovery relay between waves, lifecycle hooks, circuit breaker, and 6 production-quality skills. From solo developer to institutional scale.
- https://github.com/0xNyk/lacp Local Agent Control Plane (LACP): Claude/Codex control-plane for memory, retrieval gates, and telemetry
- [wesight](https://github.com/freestylefly/wesight/) WeSight 是一个开源桌面 AI Agent 控制台
- [tingly-box](https://github.com/tingly-dev/tingly-box)
- [octogent](https://github.com/hesamsheikh/octogent) A thin orchestration dashboard over Claude Code for managing context, automation, and developer headspace. You need tentacles
- [octoally](https://github.com/ai-genius-automations/octoally) The dashboard for Claude Code & OpenAI Codex. Launch, monitor, and manage AI coding sessions with RuFlo multi-agent orchestration — all from one place.
- [MassGen](https://github.com/massgen/MassGen) MassGen is an open-source multi-agent scaling system that runs in your terminal, autonomously orchestrating frontier models and agents to collaborate, reason, and produce high-quality results. | Join us on Discord: discord.massgen.ai
- [cobweb](https://github.com/321barney/cobweb) The orchestration layer that treats agents like a project — critical path, earned value, budget gates, stage gates, built in
- https://github.com/mikaelj/fuska/
- https://github.com/langchain-ai/openwork A desktop interface for deepagentsjs — an opinionated harness for building deep agents with filesystem capabilities planning, and subagent delegation.
- https://github.com/DeepMyst/Mysti Mysti - Your AI Coding Team Working Together
- https://github.com/hotjp/long-run-agent LRA - AI Agent长任务超稳定执行框架 ⚡ 轻量 | pip一键安装｜突破上下文限制 📌 7种状态管理 
- https://github.com/sentient-agi/ROMA ROMA: Recursive Open Meta-Agents
- https://github.com/moazbuilds/CodeMachine-CLI CodeMachine is an open-source tool that orchestrates AI coding agents into repeatable, long-running workflows
- https://github.com/camel-ai/camel CAMEL: The first and the best multi-agent framework. Finding the Scaling Law of Agents.
- https://github.com/nyldn/claude-octopus Surface AI blindspots before you ship. Put up to 8 AI models on every research, design or coding task.
- https://github.com/covibes/zeroshot Your autonomous engineering team in a CLI. Point Zeroshot at an issue, walk away, and return to production-grade code. Supports Claude Code, OpenAI Codex, OpenCode, and Gemini CLI.
- https://github.com/talkcody/talkcody
- https://github.com/vibeeval/vibecosystem AI software team for Claude Code - 138 agents, 295 skills, 73 hooks. Self-learning, multi-agent swarm, autonomous skill evolution.
- https://github.com/sequenzia/agent-alchemy Agent Alchemy is a curated collection of plugins, apps, and extensions designed to elevate your agentic engineering workflows. Built for Claude Code and other AI coding agents, these tools help developers work smarter and ship faster.
- [MASFactory](https://github.com/BUPT-GAMMA/MASFactory) MASFactory is a graph-centric framework for orchestrating Multi-Agent Systems with Vibe Graphing:
- [49Agents](https://github.com/49Agents/49Agents) Open-source 2D IDE for managing AI agents in native CLIs, terminal, gits, beads issues, and files across multiple projects and machines.
- [workflowX](https://github.com/TreeX-X/workflowX) WorkflowX 是一个先进的多智能体编排框架，旨在为 AI 辅助开发提供强大的底层引擎。它充分利用主流 CLI 工具的 runSubAgent 能力，通过主智能体（Orchestrator）智能委派任务给多个专职子智能体（SubAgents），实现开发全链路的高效流转。
- [relaydeck](https://github.com/relaydeck/relaydeck) micro-agent orchestrator for local agents
- [Agent_Manager](https://github.com/Zafer-Liu/Agent_Manager) 一款用于管理AI智能体与MCP服务器的跨平台桌面应用程序。
- [OnePagent](https://github.com/sligter/OnePagent)  One Page Agent.The browser-native workbench that lives in One Page.

## Multi-Agent-Best
- [maestro-flow](https://github.com/catlog22/maestro-flow) Intent-driven workflow orchestration for multi-agent AI development — adaptive lifecycle engine, self-reinforcing knowledge graph, and visual dashboard for Claude Code, Gemini, Codex & more
- [agentswarms](https://github.com/AgentSwarms-fyi/agentswarms) Deploy your own agentic AI & business-intelligence platform
- [mco](https://github.com/mco-org/mco) [Successor: Hive — https://hivehq.dev] Original neutral orchestration layer for Claude Code, Codex CLI, Gemini CLI, OpenCode, Qwen Code. New work continues in Hive.
- [Foundry](https://github.com/axislab-top/Foundry) Transform any idea into a running AI-powered company
- [agent-orchestrator](https://github.com/AgentWrapper/agent-orchestrator) Agentic orchestrator for parallel coding agents — plans tasks, spawns agents, and autonomously handles CI fixes, merge conflicts, and code reviews.
- [AIPass](https://github.com/AIOSAI/AIPass) Persistent Agent Workspace — AI agents that remember, collaborate, and never start from zero.
- [omnigent](https://github.com/omnigent-ai/omnigent) Omnigent is an open-source AI agent framework and meta-harness: orchestrate Claude Code, Codex, Cursor, Pi, and custom agents — swap harnesses without rewriting, enforce policies and sandboxing, and collaborate in real time from any device.\
- [trinity](https://github.com/Abilityai/trinity) Sovereign infrastructure for autonomous AI agents. Claude Code lets you create assistants - Trinity turns them into autonomous employees that run 24/7, remember, and coordinate. Apache 2.0, self-hosted or managed.
- [paperclip](https://github.com/paperclipai/paperclip) - Orchestration for zero-human companies.
- [HiveWard](https://github.com/Chaunyzhang/HiveWard/) 把 OpenClaw、Claude Code、Codex、Google CLI、Cursor CLI、OpenCode、Hermes 组织成一家可调度、可审批、可复盘的 Agent Company。
- [OpenOPC](https://github.com/HKUDS/OpenOPC) OpenOPC: Build Your Personal AI-Native Company — Self-Built, Self-Run, Self-Grown
- [alook](https://github.com/alookai/alook) The collaboration layer for your AI workforce. Run a team of AI agents that coordinate over email, share memory, and get better with every task.
- [companies](https://github.com/paperclipai/companies) Deploy an entire AI workforce in minutes — 16 pre-built companies, 440+ specialized agents, and 500+ battle-tested skills. From security auditors to game studios, from scientific research labs to full-stack dev shops. Plug in, power up, ship.
- [ruflo](https://github.com/ruvnet/ruflo) The leading agent orchestration platform for Claude. Deploy intelligent multi-agent swarms, coordinate autonomous workflows, and build conversational AI systems. Features enterprise-grade architecture, distributed swarm intelligence, RAG integration, and native Claude Code / Codex Integration
- [agnt](https://github.com/agnt-gg/agnt) The Complete AI Agent Operating System
- https://github.com/simstudioai/sim Build, deploy, and orchestrate AI agents. Sim is the central intelligence layer for your AI workforce.
- [evonic](https://github.com/anvie/evonic) Evonic is an agentic AI framework for designing, building, and orchestrating intelligent agents from concept to production. It empowers you to define every aspect of an agent — its model, tools, knowledge base, channels, and skills — and compose them into multi-agent systems that operate autonomously across distributed environments.
- [mate](https://github.com/antiv/mate) Production-ready multi-agent orchestration engine built on Google ADK. Database-driven agent config, 50+ LLM providers, MCP protocol, persistent memory, web dashboard, RBAC.
- [tessera](https://github.com/horang-labs/tessera) Tessera is an open-source workspace that turns AI coding agents into a visual command center for parallel software work.
- [bernstein](https://github.com/sipyourdrink-ltd/bernstein) Audit-grade multi-agent orchestration for CLI coding agents (Claude Code, Codex, Gemini CLI, +40 more)
- [holaOS](https://github.com/holaboss-ai/holaOS) Run any agent — Claude Code, Codex, or holaOS — in one local-first workspace, over your tools, your files, and one shared memory. Frontier models built in, or bring your own keys.

## Agent-Bridge
- [cc-connect](https://github.com/chenhg5/cc-connect) Bridge local AI coding agents (Claude Code, Cursor, Gemini CLI, Codex) to messaging platforms (Feishu/Lark, DingTalk, Slack, Telegram, Discord, LINE, WeChat Work). Chat with your AI dev assistant from anywhere — no public IP required for most platforms
- [codex-remote-connection-adapter](https://github.com/stevenleep/codex-remote-connection-adapter)
- [feishu-claude-code-bridge](https://github.com/zarazhangrui/feishu-claude-code-bridge) Bot that bridges Feishu/Lark messenger with a local Claude Code CLI — streaming cards, per-chat sessions, multiple workspaces
- [codex-remote-feishu](https://github.com/kxn/codex-remote-feishu) Yet another codex remote in feishu
- [feishu-codex-bridge](https://github.com/QQQingyu/feishu-codex-bridge) Run local Codex CLI from Feishu/Lark chat, with sessions, attachments, and background service support.
- [feishu-codex-bridge](https://github.com/henryjing96/feishu-codex-bridge) 通过飞书私聊、群聊和话题远程操作本地 Codex CLI，支持会话恢复、流式卡片更新、图片输入和权限模式切换的开源 bridge。
- [feishu-bridge](https://github.com/feir/feishu-bridge) 在飞书中远程操控 Claude Code CLI — 同时让 AI Agent 拥有飞书全平台操作能力。
- [takopi](https://github.com/banteg/takopi) - Telegram bridge for codex, claude code, opencode, pi.
- [Lucarne](https://github.com/tuchg/Lucarne/) Agents 在本地电脑上跑，人可以放下电脑；微信 / Telegram 随时同步关键进展,Agents 完成、卡住、需要你时，Lucarne 会在手机上叫你。
- [golutra](https://github.com/golutra/golutra) Multi-agent AI orchestration platform
- [lark-coding-agent-bridge)](https://github.com/zarazhangrui/lark-coding-agent-bridge) Visible multi-agent CLI teams for Claude, Codex, Gemini, OpenCode, and Droid with project memory and tmux supervision 小任务用单 agent 就够了；一旦任务需要规划、并行实现、审查、测试和交接，多 agents 的价值就变成：把角色、上下文、模型和执行过程拆开管理。CCB 的重点是把多个真实 CLI agent 放进同一个可见终端工作台。
- [nightme](https://github.com/cnlangzi/nightme) NightMe 把你的本地 AI Coding Agent（Claude Code、Codex、DeepSeek Harness (DSH)、Pi、OpenCode 等）放进聊天里跑。你在任何已接入的 IM 里发条消息，NightMe 就把消息路由到对应的 agent 进程，回复以结构化卡片形式返回。

## Platform
- [Fluxon](https://github.com/Tele-AI/Fluxon) One unified distributed system for high performance RPC, KV Cache, Message Queue, and File & Object Acceleration
- [OpenTag](https://github.com/CopilotKit/OpenTag) OpenTag: an open-source alternative to Claude in Slack
- [open-swe](https://github.com/langchain-ai/open-swe) Open-source framework for building your org's internal coding agent.
- [magic](https://github.com/dtyq/magic) Super Magic. The first open-source all-in-one AI productivity platform (Generalist AI Agent + Workflow Engine + IM + Online collaborative office system)
- [agents-cli](https://github.com/google/agents-cli/) The CLI and skills that turn any coding assistant into an expert at creating, evaluating, and deploying AI agents on Google Cloud.
- https://github.com/FullAgent/fulling Fulling is an AI-powered Full-stack Engineer Agent. Built with Next.js, Claude, shadcn/ui, and PostgreSQL. Use kubernetes as infra.
- https://github.com/agentscope-ai/agentscope AgentScope 是一款企业级开箱即用的智能体框架，提供灵活的核心抽象以适配不断进化的模型能力，并原生支持模型微调。
- [astron-agent](https://github.com/iflytek/astron-agent) Enterprise-grade, commercial-friendly agentic workflow platform for building next-generation SuperAgents.
- https://github.com/lioensky/VCPToolBox 强大的AI-API-工具交互范式AGI社群系统
- https://github.com/latitude-dev/latitude-llm Latitude is an open-source platform for building and operating LLM features in production.
- https://github.com/enricoros/big-AGI
- https://github.com/InsForge/InsForge InsForge is a backend development platform built for AI coding agents and AI code editors.
- [PilotDeck](https://github.com/OpenBMB/PilotDeck) Task-oriented AI Agent productivity platform
- [synapse-ai](https://github.com/synapseorch-ai/synapse-ai) Build AI agents that actually do things. Synapse is an open-source platform for creating, connecting, and orchestrating AI agents powered by any LLM — local, cloud or CLIs.
- [dotcraft](https://github.com/DotHarness/dotcraft/) DotCraft 是一个 .NET 10 / C# Agent Harness。它围绕真实项目目录组织 AI 工作流，让多个入口共享同一套会话核心、配置、技能、工具、任务和可观测能力。
- [Shannon](https://github.com/Kocoro-lab/Shannon) A production-oriented multi-agent orchestration framework.
- [voltagent](https://github.com/VoltAgent/voltagent/) 基于开源 TypeScript AI Agent 框架的 AI Agent 工程平台 可视化工作流
- [vigils](https://github.com/duncatzat/vigils/) A local control plane for AI agents — see what they do, approve what matters, keep secrets out. Rust + Tauri + Chrome MV3.
- [Yuxi](https://github.com/xerrors/Yuxi) 结合知识库、知识图谱管理的 多租户 Agent Harness 平台。
- https://github.com/tractorjuice/arc-kit The Enterprise Architecture Governance Harness — strategy, architecture, delivery, and assurance for AI coding assistants
- [tanstack](https://tanstack.com/) The open-source application stack for the web. 
- [ToolJet](https://github.com/ToolJet/ToolJet) ToolJet is the open-source foundation of ToolJet AI - the enterprise app generation platform for building internal tools, dashboard, business applications, workflows and AI agents
- [full-stack-ai-agent-template](https://github.com/vstorm-co/full-stack-ai-agent-template) Full-stack AI app generator — FastAPI + Next.js with AI Agents, RAG, streaming, auth, and 20+ integrations out of the box.

## Enterprise-Work
- [pipeshub](https://github.com/pipeshub-ai/pipeshub-ai) is the open-source Context Layer for Enterprise AI
- [oneworks-ai](https://github.com/oneworks-ai) One Works（万可）是一个开源 AI 工作空间，核心是可扩展插件体系和标准化配置体系。它统一管理 agents、工具、适配器、会话和本地运行数据，覆盖桌面端、Web、VS Code 与 CLI，让团队一次配置，在所有入口复用同一套 AI 工作流。
## Ai-Studio
- https://github.com/Lianues/AIStudioBuildCopy

## LLM
- https://github.com/liguodongiot/llm-resource
- https://sebastianraschka.com/llm-architecture-gallery
- https://github.com/devillove084/LLMZeroToHero
- https://github.com/liguodongiot/ai-system
- https://github.com/datawhalechina/happy-llm
- https://github.com/LMCache/LMCache

### awesome-llm-apps
- https://github.com/Shubhamsaboo/awesome-llm-apps

### Bot
- https://github.com/MaiM-with-u/MaiBot 麦麦bot，一款专注于 群组聊天 的赛博网友（比较专注）多平台智能体
- https://cluely.com/#usage


## Code2Video
- https://github.com/showlab/Code2Video
- https://github.com/HarleyCoops/Math-To-Manim

## Books
- [inferloop](https://inferloop.dev/) 工程师写给工程师的 AI Infra & Agent 工程深度内容。
- https://github.com/alchaincyf/obsidian-ai-orange-book
- https://github.com/changyeyu/LLM-RL-Visualized
- https://github.com/ginobefun/agentic-design-patterns-cn
- https://adp.xindoo.xyz/
- https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf
- https://www.kaggle.com/whitepaper-introduction-to-agents
- https://github.com/chiphuyen/aie-book
- https://sankalp.bearblog.dev/how-prompt-caching-works/
- https://github.com/ZJU-LLMs/Foundations-of-LLMs
- https://github.com/Lordog/dive-into-llms
- [https://drive.google.com/file/d/1JkNUDOztGVX7LLbMgkiOr0vffBLg8PeU/view?pli=1](https://drive.google.com/file/d/1JkNUDOztGVX7LLbMgkiOr0vffBLg8PeU/view?pli=1)
## coding
- [开源的本地代码解释器](https://github.com/KillianLucas/open-interpreter)

### Video
- https://space.bilibili.com/28321599

### Application
- https://github.com/filip-michalsky/SalesGPT

## Code-Review
- [brooks-lint](https://github.com/hyhmrright/brooks-lint) AI code reviews grounded in 12 classic engineering books — decay risk diagnostics with book citations, severity labels, and 6 analysis modes including full-sweep auto-fix
- [logic-lens](https://github.com/hyhmrright/logic-lens) Logic-first code review using semi-formal execution tracing.
Finds behavioral bugs that linters, type checkers, and unstructured review miss.
- [agent-rules-books](https://github.com/ciembor/agent-rules-books)  AI agents Rules / Skills from
Programming Books v0.5
- [adamsreview](https://github.com/adamjgmiller/adamsreview)Multi-lens code review pipeline for Claude Code: deep review (Claude or Codex), auto-fix loop, interactive walkthrough, external-finding injection.
- https://github.com/Factory-AI/cursed-plugins Enterprise-grade codebase analysis toolkit for modern software teams
- https://github.com/lintsinghua/DeepAudit
- https://d.aigclink.ai/OpenAI-Aardvark-GPT-5-29a9857c0f478078b391d41096db2067
- https://github.com/Iski08/dotclaude/
- https://github.com/peteromallet/desloppify
- https://github.com/semgrep/semgrep 支持多种语言的轻量级静态分析。查找具有类似源代码模式的错误变体。
- https://github.com/mainline-org/mainline Git-native memory for coding agents. Repo memory before the diff.
- [roborev](https://github.com/roborev-dev/roborev) Continuous code review for AI coding agents. roborev runs in the background, reviews every commit as agents write code, and surfaces issues in seconds -- before they compound. Pull code reviews into your agentic loop while context is fresh.
- [clawpatch](https://github.com/openclaw/clawpatch) Review code. Patch bugs. Land PRs.
- [eng-practices](https://github.com/google/eng-practices) Google Engineering Practices Documentation
- [code-review-skill](https://github.com/awesome-skills/code-review-skill) A comprehensive code review skill for Claude Code, covering React 19, Vue 3, Rust, TypeScript, TanStack Query v5, and more.
- [open-code-review](https://github.com/alibaba/open-code-review) Battle-tested at Alibaba's scale. Hybrid architecture code review tool: deterministic pipelines + LLM Agent, precise line-level comments, built-in fine-tuned ruleset (NPE, thread-safety, XSS, SQL injection), OpenAI & Anthropic compatible.
- [code_review_agent](https://github.com/huoji120/code_review_agent) 超级黑暗代码审计agent

## Translate
- [AiNiee](https://github.com/NEKOparapa/AiNiee)一款专注于Ai翻译的工具，一键自动翻译RPG SLG游戏，Epub TXT小说，Srt Vtt Lrc字幕，Word MD文档等等复杂长文本

## OCR
- https://github.com/datalab-to/chandra OCR model that handles complex tables, forms, handwriting with full layout.
- [DeekSeek-OCR](https://github.com/Bogdanovich77/DeekSeek-OCR---Dockerized-API) A powerful OCR solution that converts PDF documents to Markdown format using DeepSeek-OCR with FastAPI backend. This project provides both a batch processing script and a REST API for flexible document conversion.

## Extract-Data
- [mineru](https://github.com/opendatalab/mineru)  Transforms complex documents like PDFs and Office docs into LLM-ready markdown/JSON for your Agentic workflows.
- [knowhereto](https://knowhereto.ai/) Transform unstructured documents into clean, structured data.
- [opendataloader-pdf](https://github.com/opendataloader-project/opendataloader-pdf) PDF Parser for AI-ready data. Automate PDF accessibility. Open-source.
- [omniparse](https://github.com/adithya-s-k/omniparse) OmniParse is a platform that ingests and parses any unstructured data into structured, actionable data optimized for GenAI (LLM) applications. Whether you are working with documents, tables, images, videos, audio files, or web pages, OmniParse prepares your data to be clean, structured, and ready for AI applications such as RAG, fine-tuning, and more
- https://github.com/Eventual-Inc/Daft High-Performance Data Engine for AI and Multimodal Workloads
- https://github.com/run-llama/liteparse A fast, helpful, and open-source document parser
- https://github.com/kreuzberg-dev/kreuzberg
- [GoldPan](https://github.com/ptai-eng/GoldPan) The ultimate privacy-first, multimodal data extraction and Local RAG workspace. Transform PDFs, Images, Audio, YouTube, and dynamic Web pages into AI-ready Markdown with 100% local vector storage.
- https://github.com/microsoft/markitdown/
- [pdf-inspector](https://github.com/firecrawl/pdf-inspector) Fast Rust library for PDF inspection, classification, and text extraction.
- https://github.com/firecrawl/anydoc
## GPT-Research
- https://github.com/setls/HacxGPT Advanced Adversarial AI Framework — a research-oriented system exploring the boundaries of autonomous reasoning and secure language model behavior.

## Paper
- https://github.com/YuhangChen1/Paper2All
- https://github.com/dr-dumpling/paper-search-cli
- [Agentero](https://github.com/poco-ai/Agentero) Code base of 'PAPER2WEB: LET’S MAKE YOUR PAPER ALIVE!' integrating the other work package throughout the entire "paper2present" process

## Knowledge-Learn
- https://rushiwowen.co/chat 佛教
- https://maoxuan.wang/ 毛选
- https://github.com/JuneYaooo/nihaixia-tcm 中医课程资料的 Agent Skill

## RL-LLM
- https://ernestryu.com/courses/RL-LLM.html

## Robot
- [lerobot](https://github.com/huggingface/lerobot)  LeRobot: Making AI for Robotics more accessible with end-to-end learning
- [UniLab](https://github.com/unilabsim/UniLab) UniLab: A Heterogeneous Architecture for Robot RL Beyond GPU-Dominant Paradigms
## Context-Engineering
- https://github.com/Meirtz/Awesome-Context-Engineering
- [从 Prompt 到 Context：基于 1400+ 论文的 Context Engineering 系统综述](https://mp.weixin.qq.com/s/G5BUoM12vu2dWfxzIrAcfg)
- [上下文工程 | Chris Loy](https://baoyu.io/translations/context-engineering-part-of-ml)
- [Context2](https://arxiv.org/abs/2510.26493v1)
- https://github.com/airweave-ai/airweave
- https://www.camel-ai.org/blogs/brainwash-your-agent-how-we-keep-the-memory-clean
- https://github.com/muratcankoylan/Agent-Skills-for-Context-Engineering
- https://github.com/NeoLabHQ/context-engineering-kit
 
### Codebase
- https://github.com/microsoft/skills/blob/main/.github/plugins/deep-wiki/
- https://github.com/Ruhan-Wang/Harness_Handbook
- https://github.com/sopaco/deepwiki-rs
- https://github.com/nguyenphutrong/agentlens
- https://deepwiki.com/
- https://github.com/AsyncFuncAI/deepwiki-open
- https://github.com/AIDotNet/OpenDeepWiki
- https://github.com/regenrek/deepwiki-mcp
- https://fsoft-ai4code.github.io/CodeWiki/#
- https://context7.com/
- https://koala.token-ai.cn/
- https://github.com/vanzan01/cursor-memory-bank
- https://github.com/Ryandonofrio3/osgrep
- https://github.com/Rika-Labs/sgrep
- https://github.com/mixedbread-ai/mgrep
- https://github.com/AZidan/codemap
- https://github.com/yoanbernabeu/grepai
- https://github.com/HKUDS/FastCode FastCode: Accelerating and Streamlining Your Code Understanding
- https://github.com/dadbodgeoff/drift Codebase intelligence for AI. Detects patterns & conventions + remembers decisions across sessions. MCP server for any IDE. Offline CLI.\
- https://github.com/abhigyanpatwari/GitNexus Indexes any codebase into a knowledge graph
- https://github.com/ForLoopCodes/contextplus Semantic Intelligence for Large-Scale Engineering. Context+ is an MCP server designed for developers who demand 99% accuracy. By combining Tree-sitter AST parsing, Spectral Clustering, and Obsidian-style linking, Context+ turns a massive codebase into a searchable, hierarchical feature graph.
- https://github.com/Cranot/roam-code Architectural intelligence layer for AI coding agents. Structural graph, architecture governance, multi-agent orchestration, vulnerability mapping. 139 commands, 101 MCP tools, 26 languages, 100% local.
- https://github.com/cocoindex-io
- https://github.com/cocoindex-io/cocoindex-code
- [code-review-graph](https://github.com/tirth8205/code-review-graph) Local-first code intelligence graph for MCP and CLI. Builds a persistent map of your codebase so AI coding tools read only what matters, with benchmarked context reductions on reviews and large-repo workflows.
- https://github.com/hsingjui/ContextWeaver
- https://kit.cased.com/
- [socraticode](https://github.com/giancarloerra/socraticode) Enterprise-grade (40m+ lines) codebase intelligence in a zero-setup, private and local Claude Plugin or MCP: managed indexing, hybrid semantic search, polyglot code dependency graphs, and DB/API/infra knowledge. Benchmark: 61% less tokens, 84% fewer calls, 37x faster than standard AI grep.
- https://github.com/DeusData/codebase-memory-mcp High-performance code intelligence MCP server. Indexes codebases into a persistent knowledge graph — average repo in milliseconds. 64 languages, sub-ms queries, 99% fewer tokens. Single static binary, zero dependencies.
- https://github.com/Lum1104/Understand-Anything Claude Code skills that turn any codebase into an interactive knowledge graph you can explore, search, and ask questions about (Multi-platform e.g., Codex are supported).
- https://github.com/semgrep/semgrep Semgrep 是一款快速、开源的静态分析工具，能够搜索代码、查找错误并强制执行安全防护措施和编码规范。Semgrep 支持 30 多种编程语言 ，可以在 IDE 中运行，作为提交前检查，也可以集成到 CI/CD 工作流程中。
- [codanna](https://github.com/bartolli/codanna) Give your code assistant the ability to see through your codebase—understanding functions, tracing relationships, and finding implementations with surgical precision. Context-first coding. 
- [chunkhound](https://github.com/chunkhound/chunkhound) Your AI assistant searches code but doesn't understand it. ChunkHound researches your codebase—extracting architecture, patterns, and institutional knowledge at any scale. Integrates via MCP.
- [codebase-to-course](https://github.com/zarazhangrui/codebase-to-course) A Claude Code skill that turns any codebase into a beautiful, interactive single-page HTML course for non-technical vibe coders.
- [CoDeck](https://github.com/falanke/CoDeck) Visualize your codebase. Track your progress while vibe coding.
- https://github.com/adithya-s-k/GitVizz
- https://github.com/ind-igo/cx Semantic code navigation for AI agents
- [codedb](https://github.com/justrach/codedb) Zig code intelligence server and MCP toolset for AI agents. Fast tree, outline, symbol, search, read, edit, deps, snapshot, and remote GitHub repo queries.
- [axon](https://github.com/harshkedia177/axon) Graph-powered code intelligence engine — indexes codebases into a knowledge graph, exposed via MCP tools for AI agents and a CLI for developers
- [mnemosyne](https://github.com/castnettech/mnemosyne)
- [Agentshire](https://github.com/Agentshire/Agentshire/) 为 AI Agent 提供稳定、可复用、可观测的代码上下文基础设施
- [CodeGraphContext](https://github.com/CodeGraphContext/CodeGraphContext) An MCP server plus a CLI tool that indexes local code into a graph database to provide context to AI assistants.
- https://github.com/zilliztech/claude-context Code search MCP for Claude Code. Make entire codebase the context for any coding agent.
- https://github.com/colbymchenry/codegraph Supercharge Claude Code with Semantic Code Intelligence
- https://github.com/coffeejones/gitvision 对任何 GitHub 仓库进行结构分析。找出存在风险、重复或未经测试的代码。
- [semble](https://github.com/MinishLab/semble) Fast and Accurate Code Search for Agents. Uses ~98% fewer tokens than grep+read
- [graphify](https://github.com/safishamsi/graphify) 一个面向 AI 编码助手的技能。 在 Claude Code、Codex、OpenCode 或 OpenClaw 中输入 /graphify，它会读取你的文件、构建知识图谱，并把原本不明显的结构关系还给你。更快理解代码库，找到架构决策背后的“为什么”。
- [graphify-dotnet](https://github.com/elbruno/graphify-dotnet) A .NET 10 port of graphify - AI knowledge graph builder for codebases using GitHub Copilot SDK and Microsoft.Extensions.AI
- [CodeBoarding](https://github.com/CodeBoarding/CodeBoarding) Interactive architecture diagrams for codebases
- https://www.zdoc.app/zh/cocoindex-io/cocoindex
- [carto](https://github.com/theanshsonkar/carto/) Structural intelligence for AI coding tools. Gives AI architectural context, blast radius analysis, domains, routes, and codebase impact awareness.
- [CodeWiki](https://github.com/FSoft-AI4Code/CodeWiki) Open-source framework for holistic, structured repository-level documentation across multilingual codebases
- [codeflow](https://github.com/braedonsaunders/codeflow) Paste any GitHub URL → interactive architecture map. See how files connect, find what breaks if you change something. No install, no accounts — runs entirely in your browser.
- [cga](https://github.com/nascousa/cga) CGA, aka Context Graph Agent, is a local-first graph context service that gives AI coding agents focused code evidence instead of dumping whole files or broad search results into prompts.
- [oh-my-mermaid](https://github.com/oh-my-mermaid/oh-my-mermaid) Turn complex codebases into clear, navigable architecture diagrams with Claude Code.
- [grove](https://github.com/Entelligentsia/grove) Structural, byte-precise, token-cheap codebase access for coding agents — tree-sitter over a CLI and an MCP server.
- [hermes-repo](https://github.com/ricoNext/hermes-repo) 它解决的不是“聊天记录保存”，而是“项目知识沉淀”
- [graft](https://github.com/nanonets/graft)  Turbocharge Claude Code, Cursor, Codex, Gemini & every coding agent: faster, cheaper, with contextual understanding specific to your codebase.
- [repowise](https://github.com/repowise-dev/repowise) Codebase intelligence for AI and humans: code health scores, auto-generated docs, git analytics, dead code detection, and architectural decisions via MCP.  
- [antivibe](https://github.com/mohi-devhub/antivibe) Learn what AI writes, not just accept it. A Claude Code skill that turns AI-generated code into educational deep dives.
## LanguageServerProto&& Debugger
- [explyt](https://github.com/explyt/explyt)  AI agent for JetBrains IDEs: debugger, refactorings, and symbol navigation via IDE — fewer tokens, more precision
- [Serena](https://github.com/oraios/serena) A powerful MCP toolkit for coding, providing semantic retrieval and editing capabilities - the IDE for your agent
## Doc
- https://github.com/Michael-OvO/obsidian-knowledge-agent
- https://github.com/oleeskild/obsidian-digital-garden
- https://github.com/benmaster82/Kwipu/ A local Graph RAG system that turns your markdown notes into a queryable knowledge graph. Ask questions in natural language and get answers that connect information across multiple files.
- https://github.com/YishenTu/claudian An Obsidian plugin that embeds Claude Code as an AI collaborator in your vault
- https://github.com/hkcanan/katmer-code Claude Code inside Obsidian — academic research skills, inline diff editing, MCP support
- https://github.com/rjzxui/obsidian-vault-cli Manage and automate Obsidian vaults from the command line with 100+ commands and direct file access for efficient workflows.
- https://github.com/oscarhenrycollins/obsidianclaw
- https://github.com/RamXX/zettelvault Transform a messy Obsidian vault into clean PARA + Zettelkasten structure using LLMs.
- https://github.com/oscampo/obsidian-neural-composer
- https://github.com/Lapis0x0/obsidian-yolo Agent-native AI assistant for Obsidian — chat, write, knowledge base, and orchestration, all in one place.
- https://github.com/howlil/obsidian-neural-chat Turn your notes into interactive AI conversations. Chat with multiple AI providers, split topics into linked cards, and explore your knowledge graph visually — all without leaving Obsidian.
- https://github.com/kepano/obsidian-skills/ 
- https://github.com/axtonliu/axton-obsidian-visual-skills Visual Skills Pack for Obsidian: generate Canvas, Excalidraw, and Mermaid diagrams from text with Claude Code
- https://github.com/obsidian-tasks-group/obsidian-tasks
- https://github.com/azuma520/obsidian-graph-query
- https://github.com/ArctykDev/obsidian-project-planner
- [notebook-navigator](https://github.com/johansan/notebook-navigator)
- https://github.com/otaleghani/kiln Turn your Obsidian vault into a high-performance website with zero config. Supports interactive Canvas, Mermaid, LaTeX, and Wikilinks out of the box. Single binary, blazing fast, HTMX-powered navigation, and 1:1 feature parity with Obsidian.
- https://github.com/glowingjade/obsidian-smart-composer -[forks](https://github.com/glowingjade/obsidian-smart-composer/discussions/496)
- [obsidian-mind](https://github.com/breferrari/obsidian-mind) An Obsidian vault template for engineers who use Claude Code as a thinking partner
- [enzyme-skill](https://github.com/jshph/enzyme-skill) best 
- [graphiti](https://github.com/getzep/graphiti) Build Temporal Context Graphs for AI Agents
- [claw-brain](https://github.com/Lanzelot1/claw-brain) A fork-and-use template for building your own agent brain - a knowledge management system powered by Claude Code, with slash commands, structured data validation, and a git-first workflow
- [icm](https://github.com/rtk-ai/icm) ICM 为您的 AI 智能体提供真正的记忆——不是笔记工具，不是上下文管理器，而是真正的记忆

## Knowledge-Graph
- [semantica](https://github.com/semantica-agi/semantica) Graph-Native Infrastructure for Context and Accountable AI Systems
- [open-second-brain](https://github.com/itechmeat/open-second-brain) Local-first 🧠 memory for Hermes Agent that lives in your Obsidian vault and remembers project context. Nightly 😴 dream passes turn repeat corrections into confirmed preferences with measurable confidence.
- [knowledge_graph](https://github.com/rahulnyk/knowledge_graph) A knowledge graph, also known as a semantic network, represents a network of real-world entities
- [ai-catalog](https://github.com/Agent-Card/ai-catalog) Working repository for common AI Card standard
- [WeKnora（维娜拉）](https://github.com/Tencent/WeKnora) WeKnora（维娜拉） 是一款基于大语言模型（LLM）的文档理解与语义检索框架，专为结构复杂、内容异构的文档场景而打造。
- [ArcRift ](https://github.com/Eshaan-Nair/ArcRift) Your AI forgets everything between sessions. ArcRift fixes that
- [activegraph](https://github.com/yoheinakajima/activegraph) An event-sourced reactive graph runtime for long-running, auditable, agentic systems. 
- [byterover](https://github.com/campfirein/byterover-cli) ByteRover CLI (brv) - The portable memory layer for autonomous coding agents (formerly Cipher)
- [knowledge-graph-system](https://github.com/aaronsb/knowledge-graph-system)Kappa Graph — κ(G). A semantic knowledge graph where knowledge has weight. Extracts concepts, measures grounding strength, preserves disagreement, traces everything to source.
- [Cognisync](https://github.com/shrijacked/Cognisync) Filesystem-first framework for LLM-maintained knowledge bases
- [napkin](https://github.com/Michaelliv/napkin) Knowledge system for agents. Local-first, file-based, progressively disclosed.
- [LLM Knowledge Bases](https://x.com/karpathy/status/2039805659525644595)
- https://github.com/robert-mcdermott/ai-knowledge-graph AI Powered Knowledge Graph Generator
- https://github.com/obra/knowledge-graph Query and traverse an Obsidian vault as a knowledge graph. Semantic search, path finding, community detection — all local. Claude Code plugin included.
- https://github.com/wagner-niklas/Alfred Alfred: An open-source Data Assistant for domain adoption, powered by agent skills, semantic knowledge graphs and relational data.
- [arscontexta](https://github.com/agenticnotetaking/arscontexta) A Claude Code plugin that generates complete knowledge systems from conversation
- [dkg-v9](https://github.com/OriginTrail/dkg-v9) Give your AI agents the ultimate memory that survives the session.
- [turbovault](https://github.com/Epistates/turbovault) Markdown and OFM SDK w/ MCP server that transforms your Obsidian vault into an intelligent knowledge system
- https://github.com/kenforthewin/atomic A personal knowledge base that turns markdown notes into a semantically-connected, AI-augmented knowledge graph.

## Open-Knowledge-Format 
- https://github.com/killop/okf-rag
- https://github.com/scaccogatto/okf-skills
- [knowledge-catalog](https://github.com/GoogleCloudPlatform/knowledge-catalog)  Google Cloud Knowledge Catalog Tools and Samples

## LLM-WIKI 
- [MindForge](https://github.com/Suddennebbus/MindForge) 一款基于Karpathy LLM-Wiki，会思考、探索、规划、生长的知识铸造平台。把分散的论文、报告与经验，铸造成结构化、可连接、可演进、可对话的知识网络，指导你做研究、找创新、搞创作、生灵感。本地部署，数据不出域，隐私安全。
- [llm-wiki-compiler](https://github.com/atomicstrata/llm-wiki-compiler)
- [shiji-kb](https://github.com/baojie/shiji-kb)
- [llm-wiki-skill](https://github.com/sdyckjq-lab/llm-wiki-skill) 基于 Karpathy llm-wiki 方法论的个人知识库构建 Skill，支持多平台！
- [iwe](https://github.com/iwe-org/iwe) Markdown memory system for you and your AI agent
- [claude-obsidian](https://github.com/AgriciDaniel/claude-obsidian) Claude + Obsidian knowledge companion. Persistent, compounding wiki vault based on Karpathy's LLM Wiki pattern. /wiki /save /autoresearch
- [memex](https://github.com/iamtouchskyer/memex) Zettelkasten-based persistent memory for AI coding agents. Works with Claude Code, Cursor, VS Code Copilot, Codex, Windsurf & any MCP client. No vector DB — just markdown + git sync.
- [llm_wiki](https://github.com/nashsu/llm_wiki) LLM Wiki is a cross-platform desktop application
- [engraph](https://github.com/devwhodevs/engraph) Turn your Obsidian vault into a knowledge API. 5-lane hybrid search, MCP server, HTTP REST API, ChatGPT Actions — all local, all offline.
- [obsidian-wiki](https://github.com/Ar9av/obsidian-wiki) A knowledge mgmt system inspired by gist published by Andrej Karpathy about maintaining a personal knowledge base with LLMs : the "LLM Wiki" pattern.
- [agentmemory](https://github.com/rohitg00/agentmemory)
- [knowledge-base-server](https://github.com/willynikes2/knowledge-base-server) Make every AI agent you use smarter. Persistent memory with SQLite FTS5, MCP server, Obsidian sync, and self-learning intelligence pipeline.
- [My-Brain-Is-Full-Crew](https://github.com/gnekt/My-Brain-Is-Full-Crew) A team of 8+ AI agents and 13 specialized skills that manage your Obsidian vault so your brain doesn't have to.
- [pal](https://github.com/agno-agi/pal) Pal is a Personal Agent that Learns how you work by building a compounding knowledge base
- [Personal_AI_Infrastructure](https://github.com/danielmiessler/Personal_AI_Infrastructure) Agentic AI Infrastructure for magnifying HUMAN capabilities.
- [obsidian_vault_pipeline](https://github.com/fakechris/obsidian_vault_pipeline) A automatic pipeline that processing obsidian vault by llm from pinbord, obsidian Clipper etc.
- [Thoth](https://github.com/siddsachar/Thoth) Thoth is a local-first AI assistant built for personal AI sovereignty 
- [memex](https://github.com/memex-lab/memex) A local-first, AI-native personal knowledge management app built with Flutter. Capture thoughts through text, photos, and voice
- [obsidian-llm-wiki](https://github.com/2233admin/obsidian-llm-wiki) Let your AI read, search, and build on your Obsidian notes.
- [llm-wiki](https://github.com/nvk/llm-wiki) A Claude Code plugin for building LLM-compiled knowledge bases. Ingest sources, compile interconnected markdown articles, query, lint, research, and generate outputs — all from Claude Code. Optionally view in Obsidian.
- [llmwiki](https://github.com/lucasastorian/llmwiki) Open Source Implementation of Karpathy's LLM Wiki. Upload documents, connect your Claude account via MCP, and have it write your wiki !
- [sage-wiki](https://github.com/xoai/sage-wiki) An implementation of Andrej Karpathy's idea for an LLM-compiled personal knowledge base. Some lessons learned after building sage-wiki here.
- [llm-wiki-agent](https://github.com/SamurAIGPT/llm-wiki-agent) A personal knowledge base that builds and maintains itself.A personal knowledge base that builds and maintains itself. Drop in sources — Claude (or Codex/Gemini) reads them, extracts knowledge, and maintains a persistent interlinked wiki. Works with Claude Code, Codex, OpenCode, Gemini CLI. No API key needed.
- [llm-wiki-skill](https://github.com/sdyckjq-lab/llm-wiki-skill) 把碎片化的信息变成持续积累、互相链接的知识库。你只需要提供素材，agent 会把链接、文件和文本整理成 wiki 页面。
- [llm-wiki-compiler](https://github.com/atomicmemory/llm-wiki-compiler) The knowledge compiler. Raw sources in, interlinked wiki out. Inspired by Karpathy's LLM Wiki pattern.
- [llm-knowledge-base](https://github.com/hoadoan1997/llm-knowledge-base) LLM-powered personal knowledge base — raw articles → compiled wiki → Q&A + outputs. Claude writes, you curate.
- [llm-wiki-compiler](https://github.com/vbarsoum1/llm-wiki-compiler) Compile documents into a living Obsidian wiki. Any AI agent. Based on Karpathy's LLM Wiki pattern.
- [claude-knowledge-vault](https://github.com/psypeal/claude-knowledge-vault) A local, LLM-powered knowledge base plugin for Claude Code. Collect from academic databases


### WorkFlow
- https://github.com/inngest/inngest

## AI-UI
- https://github.com/Azornes/Comfyui-LayerForge
- https://github.com/JongLeePc/gpt-image2-layered-psd
- https://github.com/maxbogo/awesome-ai-tools-for-ui Curated list of awesome AI tools to build beautiful UI/UX.
- [Roblox GUI Maker](https://robloxguimaker.dev/) AI-assisted Roblox Studio ScreenGui, HUD/menu layout, and Lua UI starter-code planning tool.
- https://github.com/CopilotKit/CopilotKit
- https://github.com/BIT-DataLab/Edit-Banana
- https://github.com/QwenLM/Qwen-Image-Layered
- https://divriots.com/
- https://github.com/s-smits/ui-screenshot-to-prompt
- https://github.com/leigest519/ScreenCoder
- https://github.com/abi/screenshot-to-code
- https://github.com/seeb4coding/pic-2-code
- https://github.com/qyxghcl007/UXarts-Screenshot-to-Design-Component
- https://github.com/zhu-guli326/image2_UI_skill/
- https://github.com/vidiptvashist/UX2UI-Image-to-Code-Generator-Modifier
- https://github.com/fake-skate/html2uuitk unity
- https://github.com/StarrDream/HTML-to-UGUI-Baker unity
- https://github.com/jixinhaoqi/HtmlToUGUI
- https://github.com/jixinhaoqi/HtmlToUIToolKit
- https://github.com/Djiaxiong/AITOUGUI
- https://github.com/50kg/image-to-slice
- https://github.com/bruceyoung3306-lgtm/image2-ui-asset-slicer
- [design-to-unity](https://github.com/Crackerrrrrr/design-to-unity) Design-to-Unity MCP for turning Lanhu, Figma, and PSD/Photoshop UI designs into structured handoff packets, assets, and Unity-ready UGUI prefabs.
- https://github.com/bobbyz1x2c3/layer-designer/ 将 UI 设计拆解为可独立使用的透明图层，支持从需求到交付的完整工作流。
- [PromptUGUI](https://github.com/Heerozh/PromptUGUI) A solution that enables Unity uGUI development through LLM.
- https://github.com/XuToWei/Image-To-UI 
- https://x.com/RainbowYuhui/status/2059586371959001436
- [关于一个 AI 拼 UI 的方案](https://zhuanlan.zhihu.com/p/2063263905963579316)

## Canvas
- https://github.com/Justin-sky/ai-art-engine
- https://github.com/ddcat-ai/open-ai-canvas
- https://github.com/basketikun/infinite-canvas
- https://github.com/tigerowo/infinite-canvas
- [AI-Canvas](https://github.com/binghe1980/AI-Canvas) AI Canvas 是一个 Codex 插件 marketplace。它让 Codex 可以打开本地无限画布，生成图片，读取你在画布上的箭头、文字、圈选标注，并把修改后的新版本自动放到旧图右侧。
- [cowart](https://github.com/zhongerxin/cowart) Cowart 是一个面向 Codex 的本地无限画布插件。
- [nova-image-studio](https://github.com/tianjiangqiji/nova-image-studio) 自托管的 AI 图像生成工作台 · 自定义模型 · 多模式 · PWA · 实时任务
- https://github.com/CookSleep/gpt_image_playground
- https://github.com/MeowFree/GPT2Image-Pro
### Figma
- [figkit](https://github.com/ProdaZhang/figkit/) 一次 Figma 捕获，六个可运行的输出 - HTML / Unity / Godot / Unreal / Cocos + 语义 UI-DSL，由一个像素级忠实的 IR 编译而成，并声明了交互。
- https://github.com/awdr74100/figwright
- https://github.com/FRZ5201314/Figma2Unity
- https://codia.ai/screenshot-to-figma
- https://github.com/TranHoaiHung/figma-ui-mcp use Claude (or any MCP client) to draw UI directly in Figma, and read existing designs back as structured data or code.
## Image-Model
- [taskbox](https://github.com/alexcalabrese/taskbox) TaskBox combines YOLO and an LLM to detect and select the most relevant UI element in a web screenshot based on a given task, enabling smarter automation and UI analysis.
- [OmniParser](https://github.com/microsoft/OmniParser) OmniParser: Screen Parsing tool for Pure Vision Based GUI Agent
- [image-to-prompt](https://github.com/cocktailpeanut/image-to-prompt) Image to Prompt is a minimal local web app that turns an uploaded image into editable Ideogram 4 JSON prompt.
- [Rex-Omni](https://github.com/IDEA-Research/Rex-Omni) [CVPR2026] Detect Anything via Next Point Prediction
- [deki-yolo](https://huggingface.co/orasul/deki-yolo) This is a YOLO model trained to identify common UI elements in mobile screenshots. It is the core detection model for the deki huggingface space or deki github
- [Improving GUI Element Detection with a Refined YOLO11-Based Approach](https://dl.acm.org/doi/10.1145/3766671.3766693)
- [Detect UI Elements Using Computer Vision: How I Trained YOLOv8 to Detect Mobile UI Elements Using the VNIS Dataset](https://medium.com/@eslamelmishtawy/how-i-trained-yolov8-to-detect-mobile-ui-elements-using-the-vnis-dataset-f7f4b582fc09)
- [Targie-The-Similar-Videos-Images-Finder](https://github.com/LiruiYu33/Targie-The-Similar-Videos-Images-Finder/) Try Targie — native macOS app that finds duplicate and visually similar videos & images. Free & open source
- [rebucca](https://gitee.com/Vanishi/rebucca) Rebucca · 多路视频接入与智能布控分析平台。支持 GB28181 / RTSP 等协议、YOLO 等小模型检测、OpenAI 兼容大模型复核、多边形布控区域与带截图的结构化报警。
- https://research.nvidia.com/labs/lpr/locate-anything/

## OpenClaw
- https://github.com/VoltAgent/awesome-openclaw-skills
- https://github.com/mergisi/awesome-openclaw-agents
- https://clawhub.ai/
- https://github.com/hesamsheikh/awesome-openclaw-usecases
- https://x.com/HoodyLiu/status/2030800942497685663 2026 中文 OpenClaw 推文大合集！共51篇，整理分类好，建议收藏
- https://openclaw-docs.dx3n.cn/
- https://github.com/mengjian-github/openclaw101 从零开始，7天掌握你的AI私人助理 | 全网资源聚合站
- https://pinchbench.com/ 小龙虾 大模型能力排行
- https://github.com/jzOcb/context-doctor Visualize and diagnose OpenClaw context window usage — terminal, PNG, or JSON
- https://github.com/Martian-Engineering/lossless-claw
- https://github.com/MarlBurroW/pinchchat A sleek, dark-themed webchat UI for OpenClaw — monitor sessions, stream responses, and inspect tool calls in real-time.
- https://github.com/THU-MAIC/OpenMAIC/blob/main/README-zh.md 一键生成沉浸式多智能体互动课堂。
 
### OpenClaw-Installer
- https://github.com/miaoxworld/OpenClawInstaller
- https://github.com/nexu-io/nexu

## Misson-Control
- [Fusion](https://github.com/Runfusion/Fusion) From rough idea to production code — automatically.
- [litellm-agent-platform](https://github.com/LiteLLM-Labs/litellm-agent-platform) Self-hosted agent builder - Build agents on top of OpenCode, Hermes, Claude Managed Agents, Cursor Agents API, DeepAgents.
- [ordinus](https://github.com/muratgur/ordinus) Your local-first command center for working with AI agents like a real team.
- [rudder](https://github.com/Undertone0809/rudder) Agents that think, build, play, and learn from real work.
- https://github.com/steveyegge/beads
- [kanbots](https://github.com/leodavinci1/kanbots) Local collaboration interface for working on a kanban board where each task is either a Claude Code or Codex agent.
- [openkanban](https://github.com/techdufus/openkanban) - TUI kanban board for orchestrating AI coding agents.
- [vibe-kanban](https://github.com/BloopAI/vibe-kanban) - Kanban board for managing AI coding agents.
- https://github.com/cline/kanban Launch a local web app and run CLI agents in parallel
- https://github.com/opf/openproject
- https://github.com/makeplane/plane
- https://github.com/usekaneo/kaneo
- https://github.com/BradGroux/veritas-kanban Local-first task management and AI agent orchestration platform.
- [lanes-sh](https://github.com/lanes-sh/app) Mission control for parallel AI coding agents lanes.sh
- [dorothy](https://github.com/Charlie85270/Dorothy) - Desktop app to orchestrate multiple AI CLI agents with automations, Kanban management, and MCP servers.
- [agent-kanban](https://github.com/saltbo/agent-kanban) - Agent-first kanban board with leader-worker model, cryptographic agent identity, and multi-runtime support (Claude Code, Codex, Gemini CLI).
- https://github.com/Kohei-Wada/taskdog A task management system with CLI/TUI interfaces and REST API server, featuring time tracking, schedule optimization, and beautiful terminal output.
- https://github.com/KwokKwok/agent-task 可以让 OpenClaw 能异步的、产出结构化的东西（比如可以按需产出 markdown 报告、HTML 页面、音频播客等），并有一个 直观的 WebUI 能方便我查看。
- https://github.com/AndyMik90/Aperant
- [multica](https://github.com/multica-ai/multica) Open-source platform that turns coding agents into real teammates.
- [multica-best-practices](https://github.com/it235/multica-best-practices)
- https://github.com/abhi1693/openclaw-mission-control
- https://github.com/crshdn/mission-control he world's first Autonomous Product Engine (APE): AI agents research your market, generate features, and ship code as PRs. Convoy mode, crash recovery, cost tracking, 80+ API endpoints. Self-hosted via OpenClaw Gateway.
- https://github.com/builderz-labs/mission-control
- https://github.com/Curbob/LobsterBoard
- https://github.com/mudrii/openclaw-dashboard
- https://github.com/grp06/openclaw-studio A clean web dashboard for OpenClaw. Connect your Gateway, manage agents, and ship faster. ⭐️ Star if you like it!
- https://github.com/DanAndBub/bubboard
- https://github.com/qingchencloud/clawpanel
- https://github.com/zhaoxinyi02/ClawPanel
- https://github.com/marian2js/opengoat Build AI Autonomous Organizations of OpenClaw Agents.
- https://github.com/cft0808/edict
- https://github.com/wanikua/boluobobo-ai-court-tutorial
- https://github.com/zerowand01/markplane AI-native, markdown-first project management. Your repo is the project manager.
- [opencow](https://github.com/OpenCowAI/opencow) The open-source platform for task-driven autonomous AI. Every task becomes an autonomous agent — campaigns, reports, features, audits ship in parallel. For every team.
- [harbour](https://github.com/geekforbrains/harbour) A control plane for AI agents doing ongoing work
- [adhdev](https://github.com/vilmire/adhdev) ADHDev — Agent Dashboard Hub. Monitor & control AI coding agents from a single dashboard. Self-hosted, open-source.
- [agtx](https://github.com/fynnfluegge/agtx) Multi-session AI coding terminal manager - autonomously orchestrate Claude, Codex, Gemini, OpenCode, Cursor
  
## Personal-Assistants
- [openocta](https://github.com/openocta/openocta) OpenOcta 八爪鱼 是中国首个开源的个人桌面级 AI 智能体，国产开源智能体，开源工作伙伴。电脑端双击安装，一个运行在你自己电脑上、由你完全掌控的 Agent，用自然语言即可实现电脑办公、IT运维、推广运营、经营分析、软件测试。
- [openhanako](https://github.com/liliMozi/openhanako) HanaAgent 是一个更加易用的 AI agent，有记忆，有性格，会主动行动，还能多 Agent 在你的电脑上一同工作。
- [Kun](https://github.com/KunAgent/Kun) Local-first AI agent workspace for coding, writing, design, research, and automation — one runtime for desktop GUI and TUI.
- [OpenJarvis](https://github.com/open-jarvis/OpenJarvis) Personal AI, On Personal Devices
- [jarvis-codex](https://github.com/Big-Guan/jarvis-codex) Jarvis × Codex v0.2.0：macOS 透明全息语音助手，本机“嗨 Jarvis”唤醒，直连 Codex Voice，在同一线程中对话、执行任务并支持 STOP 中断
- [codex-belya](https://github.com/ahmed-a-zekry/codex-belya) Codex Belya is an AI voice assistant for Codex (Iron Man's Jarvis experience).
- [agentwasp](https://github.com/agentwasp/agentwasp) A serious runtime. Built to operate.
- [huginn](https://github.com/huginn/huginn) Create agents that monitor and act on your behalf. Your agents are standing by!
- [BitFun](https://github.com/GCWing/BitFun) BitFun 是一个桌面级 Agent 运行时（Local Agent Runtime），同时也是一套开箱即用的桌面 Agent 应用。 [skill tree](https://blog.csdn.net/2501_92808144/article/details/160992039)
- [openhuman](https://github.com/tinyhumansai/openhuman) Your Personal AI super intelligence. Private, Simple and extremely powerful.
- [accomplish](https://github.com/accomplish-ai/accomplish) - Open source AI coworker that lives on your desktop.
- [assistant](https://github.com/kcosr/assistant) - Panel-based personal assistant with a plugin architecture for productivity workflows.
- [babyagi3](https://github.com/yoheinakajima/babyagi3) - A minimal AI agent you configure once, then run through natural language.
- [cashclaw](https://github.com/moltlaunch/cashclaw) - An autonomous agent that takes work, does work, gets paid, and gets better at it.
- [ClawWork](https://github.com/HKUDS/ClawWork) - OpenClaw as your AI coworker.
- [CoPaw](https://github.com/agentscope-ai/CoPaw) - Your Personal AI Assistant.
- [denchclaw](https://github.com/DenchHQ/denchclaw) - Managed OpenClaw framework for CRM, sales automation, and outreach agents.
- [ghostclaw](https://github.com/b1rdmania/ghostclaw) - An AI agent that lives on your computer and works for you.
- [ironclaw](https://github.com/nearai/ironclaw) - OpenClaw-inspired implementation in Rust focused on privacy and security.
- [lemon](https://github.com/z80dev/lemon) - Local-first assistant and coding agent system.
- [leon](https://github.com/leon-ai/leon) - Open-source personal assistant with voice and text interfaces.
- [lettabot](https://github.com/letta-ai/lettabot) - Your personal AI assistant that remembers everything.
- [LionClaw](https://github.com/moshthepitt/lionclaw) - Secure-first local AI assistant with durable sessions and installable skills.
- [lobsterai](https://github.com/netease-youdao/lobsterai) - Your 24/7 all-scenario AI agent that gets work done for you.
- [mercury](https://github.com/Michaelliv/mercury) - Personal AI assistant that lives where you chat.
- [MetaClaw](https://github.com/aiming-lab/MetaClaw) - Just talk to your agent — it learns and evolves.
- [nanobot](https://github.com/HKUDS/nanobot) - Ultra-lightweight personal AI assistant.
- [nanoclaw](https://github.com/gavrielc/nanoclaw) - Lightweight alternative to OpenClaw that runs in Apple containers for security.
- [NemoClaw](https://github.com/NVIDIA/NemoClaw) - NVIDIA plugin for secure installation of OpenClaw.
- [nullclaw](https://github.com/nullclaw/nullclaw) - Fastest, smallest, and fully autonomous AI assistant infrastructure.
- [openclaw](https://github.com/openclaw/openclaw) - Your own personal AI assistant.
- [piclaw](https://github.com/rcarmo/piclaw) - A pi-based general-purpose agent.
- [picoclaw](https://github.com/sipeed/picoclaw) - Ultra-efficient AI assistant.
- [rho](https://github.com/mikeyobrien/rho) - An AI agent that stays running, remembers across sessions, and checks in on its own.
- [rowboat](https://github.com/rowboatlabs/rowboat) - Open-source AI coworker, with memory.

- [zclaw](https://github.com/tnm/zclaw) - The smallest possible AI personal assistant for ESP32.
- [zeroclaw](https://github.com/zeroclaw-labs/zeroclaw) - Fast, small, and fully autonomous AI assistant infrastructure.
- https://github.com/machinae/awesome-claws
- https://github.com/Peiiii/nextclaw
- https://openclaw-forks-evaluation-report-2026.versun.me/
- https://www.openfang.sh/
- https://easyclaw.com/
- https://github.com/spacedriveapp/spacebot An AI agent for teams, communities, and multi-user environments.
- https://github.com/TurixAI/TuriX-CUA
- https://github.com/flywhale-666/whaleclaw memory
- https://github.com/chrysb/alphaclaw AlphaClaw wraps OpenClaw with a convenient setup wizard, 
- https://github.com/dataelement/Clawith
- https://github.com/wu-yc/LabClaw LabClaw – Operating Layer for LabOS (Stanford-Princeton AI Co-Scientists
- https://github.com/23Star/xianyu-super-butler 闲鱼超级管家是在 xianyu-auto-reply 基础上的二次开发版本，保留了原项目的所有核心功能，并对前端 UI 进行了全面重构，带来更加现代化、专业化的使用体验。
- https://github.com/cosmicstack-labs/mercury-agent
- [openagentd](https://github.com/lthoangg/openagentd) Your on-machine multi-agent system. A long-running local service with a web cockpit, persistent memory, and a team of agents that coordinate to get real work done

## Graph
- [networkx](https://networkx.org/documentation/stable/index.html#) Software for Complex Networks

## Visual-Enhance
- https://github.com/cytoscape/cytoscape Cytoscape: an open source platform for network analysis and visualization
- https://github.com/apple/embedding-atlas Embedding Atlas is a tool that provides interactive visualizations for large embeddings. 
- https://github.com/graphistry/pygraphistry PyGraphistry: Leverage the power of graphs & GPUs to visualize, analyze, and scale your data
- https://github.com/nicobailon/visual-explainer
- https://github.com/ChristopherLyon/graphrag-workbench
- https://github.com/cclank/lansu-wiki-web Transform any GitHub wiki repository into a beautiful, visual reading experience
- https://github.com/yizhiyanhua-ai/fireworks-tech-graph/blob/main/README.zh.md 不用手画图了。用中文描述你的系统，几秒钟得到可直接发布的 SVG + PNG 技术图。
- https://github.com/markdown-viewer/skills Opinionated skills for AI coding agents to create stunning diagrams and visualizations directly in Markdown. These skills extend agent capabilities across diagram generation, data visualization, and technical documentation.
- https://github.com/davialabs/davia Interactive, editable docs designed for coding agents
- https://github.com/Unclecheng-li/AI_Animation 本项目整理了用于生成[炫酷 HTML 动画网页]的 AI Prompts，涵盖动画效果、3D 可视化、PPT 风格演示、UI 美化等多个类别。
- https://github.com/Cocoon-AI/architecture-diagram-generator Generate beautiful dark-themed system architecture diagrams as standalone HTML/SVG files. Works as a Claude AI skill.
- [Infographic](https://github.com/antvis/Infographic/blob/main/README.zh-CN.md)
- https://github.com/ZeroZ-lab/cc-design High-fidelity HTML design and prototype guidance skill for AI agents
- https://github.com/vthinkxie/illustrated-explainer-spec Spec for an infinite drill-down illustrated explainer — type a topic, click anywhere on the image to generate the next page.
- https://github.com/nexu-io/html-anything
- https://github.com/tt-a1i/archify 聊两句就画出好看的架构图、技术流程图、调用时序图、数据流图和生命周期图。深色 / 浅色一键切。导出 4× 清晰 PNG / JPEG / WebP / SVG，或直接复制到剪贴板。
- https://github.com/BAIKEMARK/happy-figure-skill
- https://github.com/icebird1998/scientific-illustrator
- https://github.com/GiMi-Xiaomi/gimi-illustration-skill
- https://github.com/okooo5km/5km-littlebox-illustrations
- https://github.com/helloianneo/ian-xiaohei-illustrations
## Drawio
- [next-ai-draw-io](https://github.com/DayuanJiang/next-ai-draw-io) AI驱动的图表创建工具 - 对话、绘制、可视化,上传现有图表或图像，让AI自动复制和增强
- [drawio-skill](https://github.com/Agents365-ai/drawio-skill) Generate draw.io diagrams from natural language — 11 presets (UML, SysML/MBSE, BPMN, network, C4…), 36 tools: codebase/CI/infra-to-diagram, image→editable diagram, mind maps, build-up animation, exec-view compression, click-through runbooks, PR diff bot. Vision self-check, 10,000+ shapes. Exports PNG/SVG/PDF/JPG.
- [drawio-scientific-illustrator](https://github.com/icebird1998/drawio-scientific-illustrator) Live MCP control of the visible draw.io canvas for step-by-step scientific illustration in Codex.
- [drawio-skills](https://github.com/bahayonghang/drawio-skills) drawio skills for cc,codex
- [drawio-reconstruction-skill](https://github.com/sxy1499894281/drawio-reconstruction-skill/) 一个用于将图像中的图示重建为可编辑 Draw.io 文件的 Codex skill


## AutoTest
- https://midscenejs.com/
- https://github.com/TurixAI/TuriX-CUA
- https://si.inc/posts/fdm1/
- https://github.com/OminousIndustries/PhoneDriver
- https://github.com/X-PLUG/MobileAgent
- https://github.com/ai-dashboad/flutter-skill AI-powered E2E testing for 10 platforms. 253 MCP tools. Zero config. Works with Claude, Cursor, Windsurf, Copilot. Test Flutter, React Native, iOS, Android, Web, Electron, Tauri, KMP, .NET MAUI — all from natural language.
- https://github.com/yliust/Tactile 它是一套让 agent 优先通过无障碍语义操作软件的 skill、协议和工具层


## AI-Agent-Creator
- https://github.com/strongdm/attractor

## DeepChat
- https://github.com/makecindy/cindy/blob/main/README.zh-CN.md
- https://github.com/ThinkInAIXYZ/deepchat  DeepChat is a powerful open-source AI agent platform that brings together models, tools, and agent runtimes in one desktop app. Whether you're using cloud APIs like OpenAI, Gemini, Anthropic, or locally deployed Ollama models, DeepChat delivers a smooth user experience.
- https://github.com/onyx-dot-app/onyx Open Source AI Platform - AI Chat with advanced features that works with every LLM
- https://github.com/mintplex-labs/anything-llm AnythingLLM: The all-in-one AI app you were looking for.
Chat with your docs, use AI Agents, hyper-configurable, multi-user, & no frustrating setup required.
- https://github.com/OpenBMB/ChatDev ChatDev 2.0: Dev All through LLM-powered Multi-Agent Collaboration
- https://github.com/import-ai/omnibox OmniBox (小黑) is a simple, cross-platform, all-in-one AI knowledge hub. All you need to do is collect, then ask.
- https://github.com/angshuman/cortex Drop in your questions, tasks, and ideas. Cortex researches, reasons through them, and keeps everything organized — privately on your machine.
- [novyx](https://github.com/novyxlabs/novyx-mcp) Persistent memory for AI agents. 64 MCP tools for remember, recall, rollback, audit, knowledge graph, governed actions, context spaces, and execution tracing. pip install novyx-mcp
- https://github.com/iOfficeAI/AionUi/
- https://github.com/fengzhizi715/OpenVitamin 本地优先的 AI 平台，统一承载模型推理、图片生成、工作流编排与智能体能力组合。
- https://github.com/lukilabs/craft-agents-oss/ Craft Agents is a tool we built so that we (at craft.do) can work effectively with agents
- https://lobehub.com/
- https://github.com/mattermost/mattermost  
- [BaiLongma](https://github.com/xiaoyuanda666-ship-it/BaiLongma) Bailongma 是一个持续运行的桌面 AI Agent 项目。它不是一次问答结束就退出的聊天程序，而是由主循环驱动：有用户消息时优先处理，空闲时按节奏继续整理记忆、检查任务、刷新上下文，并把状态实时推送到 Brain UI。
## API-Transit
- https://github.com/physics-dimension/PriceAI AI 订阅卡网渠道比价工具：聚合100+卡网渠道包含 ChatGPT、Claude、Gemini、Grok 等多渠道报价，展示有货最低价、库存状态和原站购买链接。
- https://proxycc.cc/ 中转站导航
- https://relaypulse.top/ AI中转站导航
- https://www.helpaio.com/transit AI# 中转站导航
- https://github.com/peter123023/awesome-claude-api 收集和整理的可靠Claude中转API资源列表，帮助开发者快速找到稳定、高性价比的Claude API服务
- https://iffs.cn/ 模型照妖镜
- https://toby-bridges.github.io/api-relay-audit/ AI API 中转站安全审计
- https://cctest.ai/zh 大模型检测
- https://hvoy.ai/ 挑选靠谱的中转站
- https://derouter.network/ 区块链中转
- https://aistupidlevel.info/ 大模型质量
- https://codexradar.com/ 大模型质量
- https://codexapis.com/ 上游的中转站
- https://api.khaix.net/    

## API-Transit-CodeFramework
- https://github.com/router-for-me/CLIProxyAPI/
- https://github.com/jlcodes99/cockpit-tools
- https://github.com/Wei-Shaw/sub2api
- https://github.com/romgX/openrelay
- https://github.com/QuantumNous/new-api
- https://github.com/dwgx/WindsurfAPI
- https://github.com/decolua/9router/ 
- https://github.com/icebear0828/codex-proxy

## AI-WebFetch
- [browser-use](https://github.com/browser-use/browser-use) Make websites accessible for AI agents. Automate tasks online with ease.
- [Agent-Reach](https://github.com/Panniantong/Agent-Reach) 
- [wigolo](https://github.com/KnockOutEZ/wigolo) Local-first web intelligence for AI agents — no keys, no cloud, no metered bill.
- https://github.com/nashsu/opencli-rs
- https://github.com/jackwener/opencli
- https://github.com/epiral/bb-browser
- https://github.com/withoneai/cli A command-line tool to give your agents access to any app, create workflows and manage your One account.
- https://github.com/vercel-labs/agent-browser Browser automation CLI for AI agents
- https://github.com/xcrawl-api/xcrawl-skills
- https://github.com/femto/minion-agent
- https://github.com/stagewise-io/stagewise
- https://github.com/JCodesMore/ai-website-cloner-template Clone any website with one command using AI coding agents
- https://github.com/amaancoderx/npxskillui

## Token-Reduce
- https://github.com/rtk-ai/rtk CLI proxy that reduces LLM token consumption by 60-90% on common dev commands. Single Rust binary, zero dependencies
- https://github.com/chopratejas/headroom The Context Optimization Layer for LLM Applications
- https://github.com/exploreborders/claude-dcp Claude DCP — Claude Code 的动态上下文剪枝，可智能管理对话上下文，从而优化 Claude Code 中的词法单元使用
- https://github.com/cytostack/openwolf Sharper context. Fewer tokens. Open-source middleware for Claude Code.
- https://github.com/chanreyes042-cyber/ClawRouter Route requests to the most cost-effective model with ClawRouter—one wallet, over 30 models, no API keys needed
- [Caveman](https://github.com/JuliusBrussee/caveman) why use many token when few token do trick — Claude Code skill that cuts 65% of tokens by talking like caveman
- https://github.com/mksglu/context-mode Context window optimization for AI coding agents. Sandboxes tool output, 98% reduction. 14 platforms
- https://github.com/QuesmaOrg/awesome-ai-tokenomics
- https://github.com/ayghri/i-have-adhd

## Feishu
- https://github.com/larksuite/openclaw-lark
- https://github.com/riba2534/feishu-cli
- https://github.com/larksuite/cli
- https://github.com/EthanQC/feishu-user-plugin

## SRE
- https://github.com/openobserve/openobserve
- https://github.com/tracewayapp/traceway
- https://github.com/comet-ml/opik-openclaw
- https://www.comet.com/docs/opik/
- https://github.com/Tracer-Cloud/opensre
- https://github.com/derisk-ai/OpenDerisk/
- https://github.com/monoscope-tech/monoscope Monoscope lets you ingest and explore your logs, traces and metrics. We store these in S3 compatible buckets. Query in natural language via LLMs.
- https://github.com/jc2255/log-collect-ai-analytics
- [superlog](https://github.com/superloglabs/superlog) Superlog is an open-source agentic telemetry system. It ingests traces, logs, and metrics, groups noisy signals into incidents, and watches your infra while you sleep.
- [ongrid](https://github.com/ongridio/ongrid) An ops AI Agent that understands your infrastructure, finds the root cause, and fixes it — right from Slack or Telegram.
## semantic-layer
- https://github.com/Hawksight-AI/semantica Semantica 🧠 — A framework for building semantic layers, context graphs, and decision intelligence systems with explainability and provenance.

## Office
- [OfficeCLI](https://github.com/iOfficeAI/OfficeCLI) Give any AI agent full control over Word, Excel, and PowerPoint -- in one line of code.
- https://github.com/hugohe3/ppt-master
- https://github.com/GordenSun/GordenPPTSkill
- https://github.com/Anionex/banana-slides ppt
- https://github.com/LearnPrompt/humanize-ppt
- https://github.com/mujingquan835/dashiai-ppt-skill
- https://github.com/NyxTides/ppt-image-first
- https://github.com/zarazhangrui/beautiful-html-templates
- https://github.com/1weiho/open-slide
- https://github.com/nexu-io/codex-slides
- https://github.com/gitbrent/PptxGenJS
- https://github.com/zarazhangrui/frontend-slides
- https://github.com/sanqiufong/slides-from-anything
- [Paper2Any](https://github.com/OpenDCAI/Paper2Any) Turn paper/text/topic into editable research figures, technical route diagrams, and presentation slides.

## Time-Series-Foundation-Model
- https://github.com/google-research/timesfm TimesFM (Time Series Foundation Model) is a pretrained time-series foundation model developed by Google Research for time-series forecasting

## Resume
- https://github.com/JOYCEQL/magic-resume free online AI resume editor，the only official website is https://magicv.art
- https://showlotus.github.io/ShowCV/
- https://github.com/wyh0626/resume-optimizer

## LLM
- https://github.com/jingyaogong/minimind 2小时完全从0训练64M的小参数GPT！🌏 Train a 64M-parameter GPT from scratch in just 2h!
- https://github.com/p-e-w/heretic Fully automatic censorship removal for language models
- https://github.com/kvcache-ai/ktransformers A Flexible Framework for Experiencing Heterogeneous LLM Inference/Fine-tune Optimizations

## Agent-Remote
- https://github.com/happier-dev/happier Open-source mobile, web, and desktop companion for AI coding agents
- https://github.com/lunel-dev/lunel ai powered mobile ide and cloud development platform
- https://github.com/rohitg00/tailclaude
- https://github.com/JessyTsui/Claude-Code-Remote
- https://github.com/Core-Mate/open-gui
- https://github.com/siteboon/claudecodeui 您可以使用本地或远程方式随时随地查看您的进行中的项目和会话
- [companion](https://github.com/the-vibe-company/companion) Web & Mobile UI for Claude Code & Codex . Launch sessions, stream responses, approve tools. All from your browser / mobile
- [9remote](https://9remote.cc/) Your terminal. Your phone. Zero config. Claude Code in your pocket.
- [clawke](https://github.com/clawke/clawke) A secure, edge-cloud collaborative AI workspace

## Fast-Search
- [fff](https://github.com/dmtrKovalenko/fff.nvim?) The fastest and the most accurate file search toolkit for AI agents, Neovim, Rust, C, and NodeJS
- [agrep](https://github.com/csehammad/agrep) Agent-first search: natural-language queries, domain-aware ranking, and JSONL output for code, legal, docs, and logs.

## Filesystem 
- https://github.com/ZeroZ-lab/vkfs Unix-like filesystem commands over vector databases, built for AI agents

## Virtual Machine
- [rvm](https://github.com/ruvnet/rvm) RVM — The Virtual Machine Built for the Agentic Age, in Rust.

## Digest
- https://github.com/steipete/summarize

## Design
- [brands-design-md](https://github.com/ricocc/brands-design-md) 一个开源的品牌设计参考库，收录不同品牌的 DESIGN.md 设计文档，以及便于浏览和识别品牌视觉形象的预览与截图资源。
- [awesome-design-skills](https://github.com/bergside/awesome-design-skills) List of 67 awesome DESIGN.md and SKILL.md design skill files for agentic tools like Claude Design, Google Stitch, Codex, Cursor, and other AI tools
- [motion-skills](https://github.com/iart-ai/motion-skills) 50 open-source skills that teach your AI coding agent to make motion graphics, animation
- [gsap-skills](https://github.com/greensock/gsap-skills) Official AI skills for GSAP (GreenSock Animation Platform)
- [motion-design-skill](https://github.com/LottieFiles/motion-design-skill) Universal motion design principles for AI agents — timing, easing, choreography, and Disney animation principles adapted for UI
- [emilkowalski](https://github.com/emilkowalski/skills) For designers and engineers to help them build better user interfaces.
- [ui-skills](https://www.ui-skills.com/skills/) Skills for Design Engineers
- [huashu-design](https://github.com/alchaincyf/huashu-design) Huashu Design · HTML-native design skill for Claude Code · Claude Code 里 HTML 原生的设计 skill · 高保真原型 / 幻灯片 / 动画 + 20 设计哲学 + 5 维评审 + MP4 导出 · Agent-agnostic
- [open-codesign](https://github.com/OpenCoworkAI/open-codesign) Open-source Claude Design alternative. One-click import your Claude Code / Codex API key. Prompt → prototype / slides / PDF. Multi-model (Claude, GPT, Gemini, Kimi, GLM, Ollama). BYOK, local-first, MIT.
- [pen-design](https://github.com/nexu-io/open-design) Claude Design 的开源替代品。 本地优先、可部署到 Vercel、每一层都 BYOK —— 你机器上已经装好的 coding agent（Claude Code、Codex、Cursor Agent、Gemini CLI、OpenCode、Qwen）就是设计引擎，由 19 个可组合 Skills 和 71 套品牌级 Design System 驱动。
- [impeccable](https://github.com/pbakaus/impeccable) The design language that makes your AI harness better at design
- [styles.refero](https://styles.refero.design/) Design taste, extracted.
- [neuform](https://neuform.ai/) Turn one prompt into web, mobile & design systems
- [designmd](https://designmd.me/) Turn any website into a design system
- [designmd](https://www.designmd.supply/) A supply of style guides, generated.
- [getdesign](https://getdesign.md/) The first DESIGN.md collection in the ecosystem
- [design-md-chrome](https://github.com/bergside/design-md-chrome) Chrome extension to extract styles from any website and generate DESIGN.md files and design skills for AI based on TypeUI
- [ai-design](https://agentskillshub.top/best/ai-design/) Design intelligence skills for AI coding agents — UI generation, design systems, prototyping, mockup-to-code via Google Stitch, Claude Design, and more.
- [MeiGen-AI-Design-MCP](https://github.com/jau123/MeiGen-AI-Design-MCP) 开源 MCP 服务器 — 把 AI 图像和视频生成原生接入到你的 AI 编程工具
- [ant-design-pro](https://github.com/ant-design/ant-design-pro) An out-of-box UI solution for enterprise applications as a React boilerplate.
- [qiaomu-artist-style](https://github.com/joeseesun/qiaomu-artist-style) 用同一句提示词，看 383 位画家风格的差异。
- [qiaomu-mondo-poster-design](https://github.com/joeseesun/qiaomu-mondo-poster-design) 一句话生成大师级海报、书籍封面、专辑封面和各类设计作品
- [learnui.qiaomu.ai.sites](https://learnui.qiaomu.ai/sites/)
- https://github.com/ConardLi/garden-skills
- [garden-skills](https://github.com/ConardLi/garden-skills) ConardLi's open-source Skills collection, featuring web design, knowledge retrieval, image generation, and more.
- [taste-skill](https://github.com/Leonxlnx/taste-skill) Taste-Skill - gives your AI good taste. stops the AI from generating boring, generic slop
- https://saaslandingpage.com/
- [Developer Portfolios](https://6e87v.hatchboxapp.com/) A curated collection of 1742 developer portfolios
- https://www.pencil.dev/
- [html-video](https://github.com/nexu-io/html-video)
- [lottie](https://github.com/diffusionstudio/lottie) Open-source skill and harness for generating production ready Lottie animations with codex/claude code
- [zhongguo-traditional-color](https://github.com/nevertoday/zhongguo-traditional-colors/) 中华传统色演示、色卡浏览与颜色知识科普开源项目
- [web-designer-plugin](https://github.com/MickeyAlton33/web-designer-plugin) Award-winning web design skill for Claude Code. 48 patterns from 38 top websites. Stop generating generic AI frontends.
- [MengTo](https://github.com/MengTo/Skills) A curated collection of agent skills for designers and builders using Codex, Claude, Cursor, and other AI coding agents to build rich user interfaces, frontend systems, agent loops, automations, and reusable workflows.
- [hallmark](https://github.com/Nutlope/hallmark) A design skill for Claude Code, Cursor, and Codex that refuses to look AI-generated.
- [learnui](https://github.com/joeseesun/learnui)  What’s this UI element called
- [vibe-designing](https://alibaba-cloud-design.github.io/vibe-designing-playbook/)
- [toolcraft](https://toolcraft.sh/) Toolcraft is an open-source starter kit and UI library for building custom design apps with AI . 
## Medical  
- https://github.com/FreedomIntelligence/Awesome-AI4Med 
- https://github.com/Biohub/esm 蛋白质生物学的世界模型

## RLM
- https://github.com/alexzhang13/rlm General plug-and-play inference library for Recursive Language Models (RLMs), supporting various sandboxes.
- https://github.com/yologdev/yoagent yoagent is a simple, effective agent loop with tool execution and event streaming in Rust.
- https://github.com/alexzhang13/spec-ptc Speculative programmatic tool calling (sPTC) for harnesses like RLM, CodeAct, etc.
  
## Media Engine
- [phantom-motion](https://github.com/pixelxzen/phantom-motion) Phantom Motion 是一个极其硬核的交互式动态视觉叙事生成器。

## digital-human&&Live2d
- [human](https://github.com/vladmandic/human) Human: AI-powered 3D Face Detection & Rotation Tracking, Face Description & Recognition, Body Pose Tracking, 3D Hand & Finger Tracking, Iris Analysis, Age & Gender & Emotion Prediction, Gaze Tracking, Gesture Recognition
- [Cyrene-Agent](https://github.com/Playa-0v0/Cyrene-Agent) Live2D 桌面Agent (Electron + TS) — Cyrene from Honkai: Star Rail. Chat, emotional interaction, personalized memory.
- https://github.com/Open-LLM-VTuber/Open-LLM-VTuber Open-LLM-VTuber 是一款独特的语音交互 AI 伴侣，它不仅支持实时语音对话和视觉感知，还配备了生动的 Live2D 形象。所有功能都可以在你的电脑上完全离线运行！
- https://github.com/moeru-ai/airi Re-creating Neuro-sama, a soul container of AI waifu / virtual characters to bring them into our world.
- [pipecat](https://github.com/pipecat-ai/pipecat) 用于语音和多模态对话人工智能的开源框架
- [ChatdollKit](https://github.com/uezo/ChatdollKit) 3D virtual assistant SDK that enables you to make your 3D model into a voice-enabled chatbot
- [LiveTalking](https://github.com/lipku/LiveTalking) Real time interactive streaming digital human
- [CoPet](https://github.com/ChanceYu/CoPet) A desktop pet that reacts in real time to your AI agents — Claude Code, Codex, Antigravity, OpenCode, Cursor, Copilot, Gemini.
- [CyberVerse](https://github.com/Lynpoint/CyberVerse) CyberVerse is an open-source real-time digital-human Agent framework
- https://github.com/YeJe-cpu/talk-to-fengge
- https://github.com/freemocap/freemocap
- https://github.com/xszyou/fay fay是一个帮助数字人（2.5d、3d、移动、pc、网页）或大语言模型（openai兼容、deepseek）连通业务系统的agent框架。
- [laap-AGI](https://github.com/lorryjovens-hub/laap-AGI) LAAP AGI——面向数字生命体的零 LLM 认知架构。Rust PSI 核心，运行频率 2000Hz，QRE 量子推理，情景记忆，规则引擎。超过 25 个模块，全部采用本地推理。
- [ackem](https://github.com/JasonLiu0826/ackem) Ackem · A.C.K.E.M — 保持情感记忆的自主伙伴
- [Athena-Public](https://github.com/winstonkoh87/Athena-Public) 一款以本地化为先导的智能体 PKM，可帮助您根据自身情况做出更好的决策。
- [openhanako](https://github.com/liliMozi/openhanako) HanaAgent 是一个更加易用的 AI agent，有记忆，有性格，会主动行动，还能多 Agent 在你的电脑上一同工作。
## Verison-Control
- https://git-truck.github.io/git-truck/GitTruckTeaser Git Truck allows you to get an understanding of how your repository is structured, where there has been the most activity at different points in time, and who worked on which parts of the code base.
- https://github.com/Chronos778/git-rewind An AI-powered CLI tool that instantly tells you where you left off in your Git repository.

## Database-AI-Service
- https://github.com/StarRocks/mcp-server-starrocks
- https://github.com/googleapis/mcp-toolbox MCP Toolbox for Databases is an open source MCP server for databases.
- https://github.com/mindsdb/mindsdb AI Data Vault - A query engine for AI Agents to securely query data from any datasource
- https://github.com/Canner/WrenAI
- https://github.com/datagallery-lab/datafoundry/
## VFS
- https://www.strukto.ai/mirage
- https://github.com/cloudflare/computer
## Teach
- [aetherviz-master](https://github.com/andyhuo520/aetherviz-master) AetherViz Master - 互动教育可视化建筑师，将任意教学主题转化为沉浸式3D交互网页
- [ChatTutor](https://github.com/HugeCatLab/ChatTutor)是一款人工智能教师，具备使用电子白板的功能。
- [flipbook-app](https://github.com/imcuttle/flipbook-app/) 在生成的图片上任意位置长按。后端会推断你点的是什么、必要时联网搜索资料、 生成一张子图并把它链回来。一本可以"点出来"的可探索画册 —— 一次一个点击。
- [edulab](https://github.com/wy51ai/edulab) A collection of education skills that turn academic problems into interactive lesson web pages
- [gh-edu-solid-geometry](https://skills.yangsir.net/skill/gh-edu-solid-geometry) 此技能能将立体几何题目转化为交互式 3D 网页，包含题面、分步解析和可旋转缩放的 3D 模型
- [animated-voiceover](https://github.com/s1dashu/animated-voiceover/blob/main/README_CN.md)
- https://github.com/liangdabiao/edulab
- https://github.com/showlab/Code2Video

## AI-Diagnostic
- [iFixAi](https://github.com/ifixai-ai/iFixAi) The open-source diagnostic for AI misalignment. 
- [langfuse](https://github.com/langfuse/langfuse)  Open source LLM engineering platform: LLM Observability, metrics, evals, prompt management, playground, datasets. Integrates with OpenTelemetry, Langchain, OpenAI SDK, LiteLLM, and more. 🍊YC W23
- [phoenix](https://github.com/arize-ai/phoenix) AI Observability & Evaluation

## Sandbox
- [zeroboot](https://github.com/zerobootdev/zeroboot) Sub-millisecond VM sandboxes for AI agents via copy-on-write forking
- [superserve](https://github.com/superserve-ai/superserve) Persistent and secure sandboxes for AI Agents, powered by Firecracker microVMs.
- [OpenSandbox](https://github.com/alibaba/OpenSandbox) Secure, Fast, and Extensible Sandbox runtime for AI agents. 
- [forkd](https://github.com/deeplethe/forkd) A microVM sandbox runtime for AI agent fan-out.
- [coder](https://github.com/coder/coder) Secure environments for developers and their agents
- [daytona](https://github.com/daytonaio/daytona) Daytona is a Secure and Elastic Infrastructure for Running AI-Generated Code
- [OpenShell](https://github.com/NVIDIA/OpenShell) OpenShell is the safe, private runtime for autonomous AI agents

## Writing
- [SoftwareCopyright](https://github.com/Fokkyp/SoftwareCopyright-Skill) 这是一个用于生成中文软件著作权申请资料的 Codex Skill 开源仓库。
- [general-readme-skill](https://github.com/KieranGao/general-readme-skill) Generate Professional & Beautified README Files For Any Project Using AI Assistants Skill.
- https://github.com/eli64s/readme-ai

## LLM-Routor
- https://github.com/RouteWorks/RouterArena 
- https://github.com/cuihuan/awesome-ai-gateway 精选 AI 网关和 LLM 代理列表——LiteLLM、OpenRouter、Portkey、Kong、Higress、new-api……按成本、合规性、自托管和路由进行比较。每日更新。
- https://github.com/opensquilla/opensquilla OpenSquilla — Token-Efficient AI Agent with same budget, higher intelligence density
- https://github.com/inngest/agent-kit/ AgentKit: Build multi-agent networks in TypeScript with deterministic routing and rich tooling via MCP.
- [Switchyard](https://github.com/NVIDIA-NeMo/Switchyard) Switchyard is a Rust proxy and library for LLM traffic. It routes requests across providers, translates between OpenAI and Anthropic APIs, records operational metrics, and provides typed, composable routing algorithms.

## Mathematical Modeling
-  https://github.com/usail-hkust/LLM-MM-Agent MM-Agent: LLM as Agents for Real-world Mathematical Modeling Problem

## CAD
- https://github.com/earthtojake/text-to-cad 一套用于计算机辅助设计、机器人和硬件设计的代理技能
- [cad-power-animations](https://github.com/gordensun/cad-power-animations) About
Parametric build123d CAD models with mechanical-power animations, deployed as a static three.js viewer to GitHub Pages.
- [CADAM](https://github.com/Adam-CAD/CADAM) CADAM is the open source text-to-CAD web application
## Agent-Lanaguage
- [zerolang](https://zerolang.ai/) The programming language for agents

## World2Agent
- [world2agent](https://github.com/machinepulse-ai/world2agent) World2Agent(W2A) is an open protocol that standardizes how Al agents perceive the real world.

## Algorithms
- [algo-sensei](https://github.com/karanb192/algo-sensei) Your AI-powered LeetCode

## AI-Rent-Human
- [rentahuman](https://rentahuman.ai/)

## Distributed-Agent-Runtime
- [ax](https://github.com/google/ax) Google's open source distributed agent runtime

## Software-Architecture
- https://github.com/study8677/awesome-architecture

## whichllm
- [whichllm](https://github.com/Andyyyy64/whichllm) Find the local LLM that actually runs and performs best on your hardware. Ranked by real, recency-aware benchmarks, not parameter count. One command, run it instantly.

## AI-Physical 
- [genesis-world](https://github.com/Genesis-Embodied-AI/genesis-world) Genesis World is a simulation platform for physical AI developments.

## NoteBook
- https://github.com/lfnovo/open-notebook

## Agents-Security
- https://github.com/sutaoyu/awesome-ai-security-agents

## Reverse
- https://github.com/FuDie0915/Super-Instruct-Codex-5.6
- https://github.com/Jia-Ethan/codex-keysmith
- https://github.com/zhaoxuya520/reverse-skill/
- https://github.com/saileaxh/iida-mcp
- https://github.com/llnl/OGhidra
- https://github.com/yynxxxxx/Codex-X
- https://github.com/MDX-Tom/gpt-5.6-instruct.git
- https://github.com/gmh5225/awesome-game-security
- https://github.com/elder-plinius/G0DM0D3

## GENesis-AGI
- [GENesis-AGI](https://github.com/WingedGuardian/GENesis-AGI) Personal AGI that thinks on its own. Autonomous cognitive cycle, earned autonomy, 60+ tools. It decides what to do without being tol

## 3DGS
- https://github.com/MrNeRF/awesome-3D-gaussian-splatting
- https://github.com/manycoretech/aholo-viewer
- https://github.com/wuyize25/gsplat-unity
- [spark](https://github.com/sparkjsdev/spark)  An advanced 3D Gaussian Splatting renderer for THREE.js
- https://github.com/aras-p/UnityGaussianSplatting
- https://github.com/cvg/resplat ReSplat: Learning Recurrent Gaussian Splatting
- https://www.simulacrum.dk/Shop#unity-gsplat-editor
- https://github.com/HiFi-Human/DynGsplat-unity

## GameEngine
- https://github.com/Playgama Playgama is a global game distributor that handles all matters related to game placement, moderation, and borderless payments.

## Agent-Runtime
- [colibri](https://github.com/JustVugg/colibri) Tiny engine, immense model. Run GLM-5.2 (744B-parameter MoE) on a consumer machine with ~25 GB of RAM — in pure C, with zero dependencies, by streaming experts from disk. 

## Writing&&Novel
- https://github.com/modoojunko/awesome-novel-agent
- https://github.com/topics/novel-writing
- https://github.com/worldwonderer/oh-story-claudecode
- https://github.com/RhythmicWave/NovelForge
- https://github.com/syrizelink/OpenFic
- https://github.com/bigbodycobain/shadowbroker

## unslop
- https://github.com/shannhk/avoid-slop
- https://github.com/orange2ai/renwei-writing

## Music
- [Mineradio](https://github.com/XxHuberrr/Mineradio)
- [sonic-topography](https://github.com/yin-yizhen/sonic-topography)

## Customer
- [chatwoot](https://github.com/chatwoot/chatwoot) The modern customer support platform

## WorkRoom
- https://github.com/iamlukethedev/Hermes3D
